<?php
require_once 'import.php';

class UnsafeCrypto
    {
        const METHOD = 'aes-256-ctr';
        
        /**
         * Encrypts (but does not authenticate) a message
         * 
         * @param string $message - plaintext message
         * @param string $key - encryption key (raw binary expected)
         * @param boolean $encode - set to TRUE to return a base64-encoded 
         * @return string (raw binary)
         */
        public static function encrypt($message, $key, $encode = false)
        {
            $nonceSize = openssl_cipher_iv_length(self::METHOD);
            $nonce = openssl_random_pseudo_bytes($nonceSize);
            
            $ciphertext = openssl_encrypt(
                $message,
                self::METHOD,
                $key,
                OPENSSL_RAW_DATA,
                $nonce
            );
            
            // Now let's pack the IV and the ciphertext together
            // Naively, we can just concatenate
            if ($encode) {
                return base64_encode($nonce.$ciphertext);
            }
            return $nonce.$ciphertext;
        }
        
        /**
         * Decrypts (but does not verify) a message
         * 
         * @param string $message - ciphertext message
         * @param string $key - encryption key (raw binary expected)
         * @param boolean $encoded - are we expecting an encoded string?
         * @return string
         */
        public static function decrypt($message, $key, $encoded = false)
        {
            if ($encoded) {
                $message = base64_decode($message, true);
                if ($message === false) {
                    throw new Exception('Encryption failure');
                }
            }

            $nonceSize = openssl_cipher_iv_length(self::METHOD);
            $nonce = mb_substr($message, 0, $nonceSize, '8bit');
            $ciphertext = mb_substr($message, $nonceSize, null, '8bit');
            
            $plaintext = openssl_decrypt(
                $ciphertext,
                self::METHOD,
                $key,
                OPENSSL_RAW_DATA,
                $nonce
            );
            
            return $plaintext;
        }
    }

$response = array('status' => 0, 'msg' => 'Something Went wrong.');

// $sql = "SELECT password FROM bot_ip_logins";
// $result = mysqli_query($conn,$sql);

// $rowsdata = mysqli_fetch_assoc($result);

// $pass= UnsafeCrypto::decrypt($rowsdata['password'], $key);
// //echo $pass;exit;
// echo $pass ;exit;



if(!empty($_POST['username']) && !empty($_POST['password'])){

	$ip_address = getHostByName(getHostName());
	$username = $_POST['username'];
	//$password = UnsafeCrypto::encrypt($_POST['password'], $key);
	$password = $_POST['password'];

	$query = "TRUNCATE `bot_ip_logins";
	$result = mysqli_query($conn,$query);


	$query = "Insert into bot_ip_logins(`ip_address`,`username`,`password`) values('".$ip_address."','".$username."','".$password."')";
	$result = mysqli_query($conn,$query);


	if($result){
		$response = array('status' => 'success', 'msg' => 'Welcome '.$username);
	}

	echo json_encode($response);
}

?>