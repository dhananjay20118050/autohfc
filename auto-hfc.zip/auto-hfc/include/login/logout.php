<?php
require_once('../import.php');
define('PROJECT_DIR', '/auto-hfc/');
session_start();
unset($_SESSION['userId']);
unset($_SESSION['emailId']);
session_destroy();
$ip_address = getHostByName(getHostName());
$query = "Delete from `bot_ip_logins where ip_address='".$ip_address."'";
$result = mysqli_query($conn,$query);

$response['target'] = PROJECT_DIR;
echo json_encode($response);
?>
