<div id="wait" style="background-color:rgba(255, 255, 255, 0.5);width:100%;height:100%;display:none;z-index:5000;position:absolute;color:white;
      top:0;left:0;right:0;bottom:0;font-size: 28;text-align: center; vertical-align: middle;">
      <h3 style="color: black; margin-top:300px;" id="loading-text-msg"><img src="css/img/loading.gif" class="none" id="wait-loading-img"><br>bot running...</h3>
</div>
</body>
<script src="js/constants.js"></script>
<script src="js/login.js"></script>
<script src="js/custom.js"></script>
<script src="lib/datatables_v1/datatables.js"></script>

</html>
<?php /* exit */?>
