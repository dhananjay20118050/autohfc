var userData = {};

var SELENIUM_API = "http://localhost/hfc/index.php/api/BOT/";
var SERVER_PATH = "http://localhost/auto-hfc/";
//var SERVER_API = "http://localhost/hfc/index.php/api/BOT/";