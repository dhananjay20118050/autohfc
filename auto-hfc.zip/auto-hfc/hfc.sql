-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 14, 2020 at 01:49 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hfc`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`bpo_pluser`@`10.1.22.117` PROCEDURE `sp_GetAlternateBankingDetail` (IN `apsNoo` VARCHAR(50))  BEGIN
   select p.applicationno,a.apsno,p.firstname,p.secondary_bank_name,p.secondry_account_number,p.secondry_account_type
 from pldataentry p inner join pl_apsformdata a on p.applicationno=a.txtappformno WHERE p.applicationno in 
(select a.txtappformno from pl_apsformdata where a.apsno=apsNoo);
END$$

CREATE DEFINER=`bpo_pluser`@`10.1.22.117` PROCEDURE `sp_GetApplicantandOfficeTVR` (IN `apsNoo` VARCHAR(50))  BEGIN
   select firstname,tel from pldataentry WHERE apsNo=apsNoo ;   
END$$

CREATE DEFINER=`root`@`%` PROCEDURE `sp_GetApp_Details` (IN `apsNoo` VARCHAR(50))  BEGIN
select b.txtAppFormNo,a.apsno,b.app_score,b.cpcs,
if(ifnull(b.cpcs,0) >0, 'Matched','Not Matched')as cpcs_status ,b.de_dupe,
if(ifnull(b.de_dupe,0)>0,'Matched','Not Matched')as de_dupe_status,b.app_id,b.cibil_Vintage, 
(case when b.cibil_Vintage<12 then 'ultrathin' when b.cibil_Vintage<24 then 'thin' else 'thick' end)as cibil_vintage_Status,b.pq_offer,
(case when ifnull(pq_offer,'N')='Y' then 'Yes' else 'No' end)as PQ_Status
from pl_apscamdata b
inner join pl_apsformdata a on b.txtAppFormNo=a.txtappformno 
where b.txtAppFormNo=(select txtappformno from pl_apsformdata where apsno=apsNoo) and b.isCamDataSaved=1;
END$$

CREATE DEFINER=`bpo_pluser`@`10.1.22.117` PROCEDURE `sp_GetBankingDetail` (IN `apsNoo` VARCHAR(50))  BEGIN
select firstname,primary_bank_name,primary_account_number,occupational_detail,name_prefix from pldataentry WHERE apsNo=apsNoo ; 
  
END$$

CREATE DEFINER=`root`@`%` PROCEDURE `sp_GetBankingDetail_ForAVG` (IN `apsNoo` VARCHAR(50))  BEGIN

select * from 
(select b.txtAppFormNo,a.apsno,cast(b.month as UNSIGNED)month,b.year,
 b.bal_5,b.bal_15,b.bal_25,b.month_avg_bal,b.times_of_emi from pl_apsbankdata b
inner join pl_apsformdata a on b.txtAppFormNo=a.txtappformno 
where b.txtAppFormNo=(select txtappformno from pl_apsformdata where apsno=apsNoo)
order by cast(b.month as UNSIGNED) desc
limit 3)Query
order by month;

END$$

CREATE DEFINER=`bpo_pluser`@`10.1.22.117` PROCEDURE `sp_GetBDTDeatils` (IN `apsNoo` VARCHAR(50))  BEGIN 
   
select P.Credit_facility_amount,P.tenure_month,SUBSTRING_INDEX(P.customer_code,'-',1) as customer_code,SUBSTRING_INDEX(P.surrogate_code,'-',1) as surrogate_code,P.promo_code,P.education,P.company_employer_name,
P.employer_desgnator,d.emp_desc,P.exp_current_job,P.exp_total_job,P.previous_employer_name,P.date_of_birth,P.marital_status,P.residence_is,P.no_of_year,P.primary_bank_name,
P.primary_account_number,ed.qualification_desc,res.residenceis_desc ,c.CategoryValue   from pldataentry P
inner join pleducationalqualification_master ed on P.education=ed.qualification_code
inner join plresidenceis_master res on P.residence_is=res.residenceis_code
Left join plemployerdesignator_master d on P.employer_desgnator=d.emp_code
Left join plcategoryvalue c on P.spouse_occupation=c.Categorycode
WHERE P.apsNo=apsNoo ; 
END$$

CREATE DEFINER=`bpo_pluser`@`10.1.22.117` PROCEDURE `sp_GetCombinedBankingDetail` (IN `apsNoo` VARCHAR(50))  BEGIN
   select firstname,secondary_bank_name,secondry_account_number,customer_category,primary_branch from pldataentry WHERE apsNo=apsNoo ;    
END$$

CREATE DEFINER=`bpo_pluser`@`10.1.22.117` PROCEDURE `sp_GetDoctor_SelfEmployed` (IN `apsNoo` VARCHAR(50))  BEGIN     
select credit_facility_amount from pldataentry WHERE apsNo=apsNoo ; 
END$$

CREATE DEFINER=`root`@`%` PROCEDURE `sp_GetEsclationDetail` (IN `apsNoo` VARCHAR(50))  BEGIN
select P.apsNo,P.credit_facility_amount,P.tenure_month,P.education,P.company_employer_name,P.exp_current_job,P.previous_employer_name,
P.spouse_occupation,P.residence_is,P.other,P.employer_desgnator,P.exp_total_job,P.residence_type,P.residence_is,P.no_of_year,P.primary_bank_name,
P.primary_account_number,SUBSTRING_INDEX(P.customer_code,'-',1) as customer_code,SUBSTRING_INDEX(P.surrogate_code,'-',1) as surrogate_code,a.txtAddressOne_4,d.emp_desc,ed.qualification_desc,res.residenceis_desc,
P.promo_code,
(case when trim(left(Ifnull(P.promo_code,'NA'),2))='NA' then 'Fresh' when P.promo_code='' then 'Fresh' else P.promo_code end)as Promo_Status
from pldataentry P inner join pl_apsformdata a on P.applicationno=a.txtappformno 
Left join plemployerdesignator_master d on P.employer_desgnator=d.emp_code 
inner join pleducationalqualification_master ed on P.education=ed.qualification_code
inner join plresidenceis_master res on P.residence_is=res.residenceis_code
WHERE  P.apsNo = (select apsno from pl_apsformdata where apsno=apsNoo) ;  
        
END$$

CREATE DEFINER=`bpo_pluser`@`10.1.22.117` PROCEDURE `sp_GetReferenceTVR` (IN `apsNoo` VARCHAR(50))  BEGIN    
 select reference1_name,reference1_phone,reference1_add,kyc_verification_emp_designation,reference1_relationship,reference2_name,
reference2_phone,reference2_add,reference2_relationship,concat(std_code,'-',tel) As tel,residentmobile,concat(companystd,'-',company_tel) As company_tel,exp_current_job,no_of_year,exp_total_job 
 from pldataentry  WHERE apsNo=apsNoo ; 
END$$

CREATE DEFINER=`bpo_pluser`@`10.1.22.117` PROCEDURE `sp_GetSalariedDetail` (IN `apsNoo` VARCHAR(50))  BEGIN
select CONCAT(p.firstname,' ',p.middle_name,'',p.surname) As Name, p.credit_facility_amount,p.tenure_month from pldataentry p inner join pl_apsformdata a on p.applicationno=a.txtappformno 
WHERE a.apsNo in (select a.apsno from pl_apsformdata where a.apsno=apsNoo);
update pldataentry  set apsno=(select apsno from pl_apsformdata where apsno=apsNoo) 
where applicationno=(select txtappformno from pl_apsformdata where apsno=apsNoo);
       
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `bot_aps_tracking`
--

CREATE TABLE `bot_aps_tracking` (
  `tracking_id` int(11) NOT NULL,
  `TRNREFNO` varchar(255) DEFAULT NULL,
  `start_time` varchar(45) DEFAULT NULL,
  `end_time` varchar(45) DEFAULT NULL,
  `status` varchar(2) DEFAULT NULL,
  `last_process_entry` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `userid` varchar(11) NOT NULL,
  `upload_datetime` varchar(45) NOT NULL,
  `upload_user` int(11) NOT NULL,
  `is_pan_checked` int(1) NOT NULL DEFAULT 0,
  `is_logged_in` int(1) NOT NULL DEFAULT 0,
  `is_processed` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bot_aps_tracking`
--

INSERT INTO `bot_aps_tracking` (`tracking_id`, `TRNREFNO`, `start_time`, `end_time`, `status`, `last_process_entry`, `ip_address`, `userid`, `upload_datetime`, `upload_user`, `is_pan_checked`, `is_logged_in`, `is_processed`) VALUES
(5, '7431346', '2020-02-14 13:28:11', '2020-02-14 13:30:34', 'Y', 0, '10.27.175.126', '1', '2020-02-14 12:24:07', 1, 1, 0, 'Yes'),
(6, '7431276', '2020-02-14 17:41:14', '2020-02-14 17:43:12', 'E', 0, '10.27.175.126', '1', '2020-02-14 12:24:07', 1, 1, 0, ''),
(7, '7431279', '2020-02-14 14:49:02', '2020-02-14 14:55:51', 'Y', 0, '10.27.175.126', '1', '2020-02-14 12:24:07', 1, 1, 0, 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `bot_aps_trackingold`
--

CREATE TABLE `bot_aps_trackingold` (
  `tracking_id` int(11) NOT NULL,
  `txtAppFormNo` varchar(255) DEFAULT NULL,
  `apsNo` varchar(255) DEFAULT NULL,
  `start_time` varchar(45) DEFAULT NULL,
  `end_time` varchar(45) DEFAULT NULL,
  `start_userId` int(11) DEFAULT NULL,
  `resume_userId` int(11) DEFAULT NULL,
  `status` varchar(1) DEFAULT NULL,
  `last_process_entry` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `isCibilDownloaded` int(1) DEFAULT 0,
  `isSourcing` int(1) DEFAULT 0,
  `IsCamGen` int(11) DEFAULT NULL,
  `qc_status` varchar(1) DEFAULT 'N',
  `cam_status` varchar(1) DEFAULT 'N',
  `is_auto_qc_done` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bot_aps_trackingold`
--

INSERT INTO `bot_aps_trackingold` (`tracking_id`, `txtAppFormNo`, `apsNo`, `start_time`, `end_time`, `start_userId`, `resume_userId`, `status`, `last_process_entry`, `ip_address`, `isCibilDownloaded`, `isSourcing`, `IsCamGen`, `qc_status`, `cam_status`, `is_auto_qc_done`) VALUES
(1, '1234567', NULL, '2019-06-12 16:57:38', '2019-08-06 15:47:25', 0, NULL, 'E', 0, '10.1.42.209', 0, 0, NULL, 'N', 'N', 0),
(2, '51008456385', NULL, '2019-06-12 16:57:38', NULL, 0, NULL, 'N', 1, '10.1.42.209', 0, 0, NULL, 'N', 'N', 0),
(3, '51008456347', NULL, '2019-06-12 16:57:38', NULL, 0, NULL, 'N', 1, '10.1.42.209', 0, 0, NULL, 'N', 'N', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bot_control_mst`
--

CREATE TABLE `bot_control_mst` (
  `control_id` int(5) NOT NULL,
  `desc` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bot_control_mst`
--

INSERT INTO `bot_control_mst` (`control_id`, `desc`) VALUES
(1, 'Input Box'),
(2, 'Button'),
(3, 'Select'),
(4, 'Link'),
(5, 'Wait for URL'),
(6, 'Wait for Alert'),
(7, 'Wait for Implicit Time'),
(8, 'Wait for Element Visibility'),
(9, 'Switch Frame'),
(10, 'Switch Default Frame'),
(11, 'Switch Window'),
(12, 'Radio'),
(13, 'Function');

-- --------------------------------------------------------

--
-- Table structure for table `bot_error_logs`
--

CREATE TABLE `bot_error_logs` (
  `log_id` int(11) NOT NULL,
  `exception_class` varchar(255) DEFAULT NULL,
  `TRNREFNO` varchar(100) DEFAULT NULL,
  `exception_dtl` varchar(5000) DEFAULT NULL,
  `datetime` timestamp NULL DEFAULT current_timestamp(),
  `error_section` varchar(100) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `screenshot_path` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bot_error_logs`
--

INSERT INTO `bot_error_logs` (`log_id`, `exception_class`, `TRNREFNO`, `exception_dtl`, `datetime`, `error_section`, `userId`, `screenshot_path`) VALUES
(1, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431301', 'Currently focused window has been closed.\n', '2020-02-14 06:56:21', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431301_2020_02_14_12_26_21.png'),
(2, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431279', 'Modal dialog present: The menu data cannot be fetched . Retry after sometime.\n', '2020-02-14 06:59:45', 'Search Customer ID Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_12_29_45.png'),
(3, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431279', 'Unable to find element with css selector == #usertxt\n', '2020-02-14 07:01:13', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_12_31_13.png'),
(4, 'Facebook\\WebDriver\\Exception\\TimeOutException', '7431346', '', '2020-02-14 07:04:32', 'Start NEW CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_12_34_32.png'),
(5, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431346', 'Modal dialog present: Are you sure you want to logout?\n', '2020-02-14 07:07:20', 'General Tab Entry Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_12_37_20.png'),
(6, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431346', 'Unable to find element with css selector == *[name=\'AccountBO.PhoneEmail.PhoneEmailType\']\n', '2020-02-14 07:10:31', 'General Tab Entry Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_12_40_31.png'),
(7, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431346', 'Unable to find element with css selector == #moreInfoContainer\n', '2020-02-14 07:16:11', 'General Tab Entry Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_12_46_11.png'),
(8, 'Facebook\\WebDriver\\Exception\\UnknownServerException', '7431346', 'java.net.SocketException: Connection reset\n', '2020-02-14 07:17:10', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_12_47_10.png'),
(9, 'Facebook\\WebDriver\\Exception\\UnknownServerException', '7431279', 'Connection refused: connect', '2020-02-14 07:17:23', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_12_47_23.png'),
(10, 'Facebook\\WebDriver\\Exception\\UnknownServerException', '7431279', 'Connection refused: connect', '2020-02-14 07:17:29', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_12_47_29.png'),
(11, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431279', '', '2020-02-14 07:17:29', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_12_47_29.png'),
(12, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431279', '', '2020-02-14 07:17:29', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_12_47_29.png'),
(13, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431279', '', '2020-02-14 07:17:30', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_12_47_30.png'),
(14, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431279', '', '2020-02-14 07:17:36', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_12_47_36.png'),
(15, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431346', 'Unable to find element with css selector == *[name=\'AccountBO.PhoneEmail.PhoneEmailType\']\n', '2020-02-14 07:21:05', 'General Tab Entry Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_12_51_05.png'),
(16, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == #docNo\n', '2020-02-14 07:25:50', 'Search Customer ID Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_12_55_50.png'),
(17, 'Facebook\\WebDriver\\Exception\\UnknownServerException', '7431346', 'Connection refused: connect', '2020-02-14 07:27:03', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_12_57_03.png'),
(18, 'Facebook\\WebDriver\\Exception\\UnknownServerException', '7431346', 'Connection refused: connect', '2020-02-14 07:27:07', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_12_57_07.png'),
(19, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431346', '', '2020-02-14 07:27:08', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_12_57_08.png'),
(20, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431346', '', '2020-02-14 07:27:08', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_12_57_08.png'),
(21, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431346', '', '2020-02-14 07:27:09', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_12_57_09.png'),
(22, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431346', '', '2020-02-14 07:27:15', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_12_57_15.png'),
(23, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431346', 'Unable to find element with css selector == *[name=\'AccountBO.PhoneEmail.PhoneEmailType\']\n', '2020-02-14 07:30:36', 'General Tab Entry Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_00_36.png'),
(24, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431346', 'Unable to find element with css selector == *[name=\'AccountBO.PhoneEmail.PhoneEmailType\']\n', '2020-02-14 07:34:46', 'General Tab Entry Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_04_46.png'),
(25, 'Facebook\\WebDriver\\Exception\\UnknownServerException', '7431346', 'java.net.SocketException: Connection reset\n', '2020-02-14 07:35:56', 'Start NEW CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_05_56.png'),
(26, 'Facebook\\WebDriver\\Exception\\UnknownServerException', '7431346', 'Connection refused: connect', '2020-02-14 07:36:01', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_06_01.png'),
(27, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431346', '', '2020-02-14 07:36:01', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_06_01.png'),
(28, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431346', '', '2020-02-14 07:36:01', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_06_01.png'),
(29, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431346', '', '2020-02-14 07:36:03', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_06_03.png'),
(30, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431346', '', '2020-02-14 07:36:09', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_06_09.png'),
(31, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431346', '', '2020-02-14 07:36:48', 'Start NEW CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_06_48.png'),
(32, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431346', '', '2020-02-14 07:36:55', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_06_55.png'),
(33, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431346', '', '2020-02-14 07:37:01', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_07_01.png'),
(34, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431346', '', '2020-02-14 07:37:08', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_07_08.png'),
(35, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431346', 'Modal dialog present: Enter a value in the field.\n', '2020-02-14 07:42:20', 'Primary Account Creation', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_12_20.png'),
(36, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431346', '', '2020-02-14 07:46:54', 'Primary Account Creation', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_16_54.png'),
(37, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431346', '', '2020-02-14 07:47:00', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_17_00.png'),
(38, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431346', '', '2020-02-14 07:47:07', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_17_07.png'),
(39, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431346', '', '2020-02-14 07:47:13', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_17_13.png'),
(40, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431346', '', '2020-02-14 07:47:20', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_17_20.png'),
(41, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431346', '', '2020-02-14 07:47:27', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_17_27.png'),
(42, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431346', '', '2020-02-14 07:47:42', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_17_42.png'),
(43, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431346', '', '2020-02-14 07:55:00', 'Primary Account Creation', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_25_00.png'),
(44, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431346', '', '2020-02-14 07:55:06', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_25_06.png'),
(45, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431346', '', '2020-02-14 07:55:13', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_25_13.png'),
(46, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431346', '', '2020-02-14 07:55:19', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_25_19.png'),
(47, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431346', 'Currently focused window has been closed.\n', '2020-02-14 07:57:45', 'Primary Account Creation', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431346_2020_02_14_13_27_45.png'),
(48, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431276', 'Modal dialog present: Are you sure you want to logout?\n', '2020-02-14 08:04:55', 'Search Customer ID Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_13_34_55.png'),
(49, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == #IFrmtab0\n', '2020-02-14 08:08:05', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_13_38_05.png'),
(50, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431276', 'Currently focused window has been closed.\n', '2020-02-14 08:13:59', 'EDIT cifid_1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_13_43_59.png'),
(51, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == #usertxt\n', '2020-02-14 08:14:38', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_13_44_38.png'),
(52, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431276', 'Currently focused window has been closed.\n', '2020-02-14 08:16:56', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_13_46_56.png'),
(53, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431276', 'Window is closed\n', '2020-02-14 08:16:59', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_13_46_59.png'),
(54, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == #usertxt\n', '2020-02-14 08:17:22', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_13_47_22.png'),
(55, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == *[name=\'ScreensTOCFrm\']\n', '2020-02-14 08:18:57', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_13_48_57.png'),
(56, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431276', 'Modal dialog present: Are you sure you want to logout?\n', '2020-02-14 08:19:21', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_13_49_21.png'),
(57, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431276', 'Modal dialog present: You have not specified the From Date. As a result, it might take a long time for the results to display. \nDo you wish to continue?\n', '2020-02-14 08:20:47', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_13_50_47.png'),
(58, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431276', 'Modal dialog present: You have not specified the From Date. As a result, it might take a long time for the results to display. \nDo you wish to continue?\n', '2020-02-14 08:20:50', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_13_50_50.png'),
(59, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431276', 'Modal dialog present: Are you sure you want to logout?\n', '2020-02-14 08:20:52', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_13_50_52.png'),
(60, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431276', 'Modal dialog present: Are you sure you want to logout?\n', '2020-02-14 08:20:55', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_13_50_55.png'),
(61, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431276', 'Modal dialog present: Are you sure you want to logout?\n', '2020-02-14 08:20:58', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_13_50_58.png'),
(62, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == #usertxt\n', '2020-02-14 08:21:34', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_13_51_34.png'),
(63, 'Facebook\\WebDriver\\Exception\\TimeOutException', '7431279', '', '2020-02-14 08:23:55', 'Start NEW CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_13_53_55.png'),
(64, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431279', '', '2020-02-14 08:27:58', 'General Tab Entry Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_13_57_58.png'),
(65, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431279', '', '2020-02-14 08:28:05', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_13_58_05.png'),
(66, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431279', '', '2020-02-14 08:28:11', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_13_58_11.png'),
(67, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431279', '', '2020-02-14 08:28:17', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_13_58_17.png'),
(68, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431279', '', '2020-02-14 08:28:23', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_13_58_23.png'),
(69, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431279', '', '2020-02-14 08:28:29', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_13_58_29.png'),
(70, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431279', '', '2020-02-14 08:28:51', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_13_58_51.png'),
(71, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431279', 'Modal dialog present: Are you sure you want to logout?\n', '2020-02-14 08:38:26', 'General Tab Entry Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_08_26.png'),
(72, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431279', 'Unable to find element with css selector == *[name=\'AccountBO.Address.PreferredFormat\']\n', '2020-02-14 08:44:36', 'General Tab Entry Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_14_36.png'),
(73, 'Facebook\\WebDriver\\Exception\\UnknownServerException', '7431279', 'java.net.SocketException: Connection reset\n', '2020-02-14 08:44:49', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_14_49.png'),
(74, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431279', 'Unable to find element with css selector == #moreInfoContainer\n', '2020-02-14 08:51:23', 'General Tab Entry Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_21_23.png'),
(75, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431276', 'Currently focused window has been closed.\n', '2020-02-14 08:53:40', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_14_23_40.png'),
(76, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431279', 'Modal dialog present: Are you sure you want to logout?\n', '2020-02-14 08:55:13', 'Frame Not Found', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_25_13.png'),
(77, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431279', 'Modal dialog present: Are you sure you want to logout?\n', '2020-02-14 08:55:15', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_25_15.png'),
(78, 'Facebook\\WebDriver\\Exception\\TimeOutException', '7431279', '', '2020-02-14 09:00:27', 'Start NEW CIFID2', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_30_27.png'),
(79, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431279', 'Currently focused window has been closed.\n', '2020-02-14 09:03:24', 'General Tab Entry Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_33_24.png'),
(80, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431279', 'Unable to find element with css selector == *[name=\'AccountBO.PhoneEmail.PhoneEmailType1\']\n', '2020-02-14 09:07:21', 'General Tab Entry Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_37_21.png'),
(81, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431279', 'Currently focused window has been closed.\n', '2020-02-14 09:09:09', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_39_09.png'),
(82, 'Facebook\\WebDriver\\Exception\\UnknownServerException', '7431279', 'Connection refused: connect', '2020-02-14 09:12:22', 'General Tab Entry Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_42_22.png'),
(83, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431279', 'Modal dialog present: Do you want to reset the previous session and re-login ?\n', '2020-02-14 09:13:08', 'Start NEW CIFID2', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_43_08.png'),
(84, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431279', '', '2020-02-14 09:13:36', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_43_36.png'),
(85, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431279', '', '2020-02-14 09:13:43', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_43_43.png'),
(86, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431279', '', '2020-02-14 09:13:50', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_43_50.png'),
(87, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431279', '', '2020-02-14 09:13:56', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_43_56.png'),
(88, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431279', '', '2020-02-14 09:14:04', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_44_04.png'),
(89, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431279', '', '2020-02-14 09:14:28', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_44_28.png'),
(90, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431279', 'Modal dialog present: Are you sure you want to logout?\n', '2020-02-14 09:18:26', 'General Tab Entry Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431279_2020_02_14_14_48_26.png'),
(91, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431276', 'Currently focused window has been closed.\n', '2020-02-14 09:28:56', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_14_58_56.png'),
(92, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == #usertxt\n', '2020-02-14 09:29:21', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_14_59_21.png'),
(93, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == #moreInfoContainer\n', '2020-02-14 09:32:22', 'EDIT cifid_1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_02_22.png'),
(94, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431276', 'Currently focused window has been closed.\n', '2020-02-14 09:35:36', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_05_36.png'),
(95, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == #moreInfoContainer\n', '2020-02-14 09:38:14', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_08_14.png'),
(96, 'Facebook\\WebDriver\\Exception\\UnknownServerException', '7431276', 'java.net.SocketException: Connection reset\n', '2020-02-14 09:39:24', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_09_24.png'),
(97, 'Facebook\\WebDriver\\Exception\\UnknownServerException', '7431276', 'Connection refused: connect', '2020-02-14 09:39:29', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_09_29.png'),
(98, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431276', '', '2020-02-14 09:39:29', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_09_29.png'),
(99, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431276', '', '2020-02-14 09:39:30', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_09_30.png'),
(100, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431276', '', '2020-02-14 09:39:31', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_09_31.png'),
(101, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431276', '', '2020-02-14 09:39:36', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_09_36.png'),
(102, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 09:39:48', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_09_48.png'),
(103, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 09:39:53', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_09_53.png'),
(104, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 09:39:58', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_09_58.png'),
(105, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 09:40:03', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_10_03.png'),
(106, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 09:40:06', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_10_06.png'),
(107, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 09:40:11', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_10_11.png'),
(108, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 09:40:19', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_10_19.png'),
(109, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == #usertxt\n', '2020-02-14 09:41:09', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_11_09.png'),
(110, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == #moreInfoContainer\n', '2020-02-14 09:43:45', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_13_45.png'),
(111, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == #usertxt\n', '2020-02-14 09:47:50', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_17_50.png'),
(112, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == *[name=\'FilterParam1\']\n', '2020-02-14 09:49:48', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_19_48.png'),
(113, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == *[name=\'AccountBO.PhoneEmail.PhoneNo.cntrycode\']\n', '2020-02-14 09:52:19', 'EDIT cifid_1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_22_19.png'),
(114, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 09:59:54', 'EDIT cifid_1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_29_54.png'),
(115, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:00:00', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_30_00.png'),
(116, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:00:06', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_30_06.png'),
(117, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:00:12', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_30_12.png'),
(118, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:00:19', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_30_19.png'),
(119, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:00:26', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_30_26.png'),
(120, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:00:43', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_30_43.png'),
(121, 'Facebook\\WebDriver\\Exception\\TimeOutException', '7431276', '', '2020-02-14 10:08:53', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_38_53.png'),
(122, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:11:35', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_41_35.png'),
(123, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:11:41', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_41_41.png'),
(124, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:11:46', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_41_46.png'),
(125, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:11:52', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_41_52.png'),
(126, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:11:59', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_41_59.png'),
(127, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:12:06', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_42_06.png'),
(128, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:12:20', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_42_20.png'),
(129, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:13:50', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_43_50.png'),
(130, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:13:56', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_43_56.png'),
(131, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:14:03', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_44_03.png'),
(132, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:14:09', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_44_09.png'),
(133, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:14:16', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_44_16.png'),
(134, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:14:22', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_44_22.png'),
(135, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:14:39', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_44_39.png'),
(136, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431276', 'Modal dialog present: Do you want to reset the previous session and re-login ?\n', '2020-02-14 10:20:23', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_50_23.png'),
(137, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:20:50', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_50_50.png'),
(138, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:20:57', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_50_57.png'),
(139, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431276', '', '2020-02-14 10:21:02', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_51_02.png'),
(140, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431276', '', '2020-02-14 10:21:04', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_51_04.png'),
(141, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == *[name=\'tempFrm\']\n', '2020-02-14 10:24:06', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_54_06.png'),
(142, 'Facebook\\WebDriver\\Exception\\UnknownServerException', '7431276', 'java.net.SocketException: Connection reset\n', '2020-02-14 10:24:38', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_54_38.png'),
(143, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:27:11', 'EDIT cifid_1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_57_11.png'),
(144, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:27:18', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_57_18.png'),
(145, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:27:24', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_57_24.png'),
(146, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:27:31', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_57_31.png'),
(147, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:27:36', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_57_36.png'),
(148, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:27:44', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_57_44.png'),
(149, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:28:03', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_15_58_03.png'),
(150, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431276', 'Currently focused window has been closed.\n', '2020-02-14 10:33:10', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_03_10.png'),
(151, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431276', 'Window is closed\n', '2020-02-14 10:33:13', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_03_13.png'),
(152, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == #moreInfoContainer\n', '2020-02-14 10:48:03', 'EDIT cifid_1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_18_03.png'),
(153, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:48:09', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_18_09.png'),
(154, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:48:15', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_18_15.png'),
(155, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:48:21', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_18_21.png'),
(156, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:48:27', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_18_27.png'),
(157, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 10:48:36', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_18_36.png'),
(158, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == #usertxt\n', '2020-02-14 11:14:35', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_44_35.png'),
(159, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431276', 'Currently focused window has been closed.\n', '2020-02-14 11:18:40', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_48_40.png'),
(160, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == #moreInfoContainer\n', '2020-02-14 11:21:02', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_51_02.png'),
(161, 'Facebook\\WebDriver\\Exception\\UnknownServerException', '7431276', 'java.net.SocketException: Connection reset\n', '2020-02-14 11:22:14', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_52_14.png'),
(162, 'Facebook\\WebDriver\\Exception\\UnknownServerException', '7431276', 'Connection refused: connect', '2020-02-14 11:22:19', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_52_19.png'),
(163, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431276', '', '2020-02-14 11:22:19', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_52_19.png'),
(164, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431276', '', '2020-02-14 11:22:19', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_52_19.png'),
(165, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431276', '', '2020-02-14 11:22:20', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_52_20.png'),
(166, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431276', '', '2020-02-14 11:22:25', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_52_25.png'),
(167, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431276', 'Modal dialog present: Do you want to reset the previous session and re-login ?\n', '2020-02-14 11:22:59', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_52_59.png'),
(168, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:23:21', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_53_21.png'),
(169, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:23:28', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_53_28.png'),
(170, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:23:34', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_53_34.png'),
(171, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:23:40', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_53_40.png'),
(172, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:23:50', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_53_50.png'),
(173, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:24:13', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_16_54_13.png'),
(174, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with xpath == //*[@id=\"PhoneEmailRecordSet\"]/tbody/tr[4]/td[7]/input\n', '2020-02-14 11:31:23', 'EDIT cifid_1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_01_23.png'),
(175, 'Facebook\\WebDriver\\Exception\\UnexpectedAlertOpenException', '7431276', 'Modal dialog present: Do you want to reset the previous session and re-login ?\n', '2020-02-14 11:36:34', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_06_34.png'),
(176, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:36:58', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_06_58.png'),
(177, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:37:04', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_07_04.png'),
(178, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:37:10', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_07_10.png'),
(179, 'Facebook\\WebDriver\\Exception\\NoSuchDriverException', '7431276', '', '2020-02-14 11:37:14', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_07_14.png'),
(180, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == *[name=\'PsychographicBO.MiscellaneousInfo.strText10\']\n', '2020-02-14 11:41:16', 'EDIT cifid_1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_11_16.png'),
(181, 'Facebook\\WebDriver\\Exception\\UnknownServerException', '7431276', 'Connection refused: connect', '2020-02-14 11:42:29', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_12_29.png'),
(182, 'Facebook\\WebDriver\\Exception\\UnknownServerException', '7431276', 'Connection refused: connect', '2020-02-14 11:42:34', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_12_34.png'),
(183, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == *[name=\'appSelect\']\n', '2020-02-14 11:45:33', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_15_33.png'),
(184, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:46:57', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_16_57.png'),
(185, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:47:00', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_17_00.png'),
(186, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:47:04', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_17_04.png'),
(187, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:47:08', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_17_08.png'),
(188, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:47:13', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_17_13.png'),
(189, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:47:18', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_17_17.png'),
(190, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:47:25', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_17_25.png'),
(191, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == *[name=\'appSelect\']\n', '2020-02-14 11:55:13', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_25_13.png'),
(192, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:56:36', 'Finacle Login Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_26_36.png');
INSERT INTO `bot_error_logs` (`log_id`, `exception_class`, `TRNREFNO`, `exception_dtl`, `datetime`, `error_section`, `userId`, `screenshot_path`) VALUES
(193, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:56:40', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_26_40.png'),
(194, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:56:45', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_26_45.png'),
(195, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:56:48', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_26_48.png'),
(196, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:56:54', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_26_54.png'),
(197, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:56:58', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_26_58.png'),
(198, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 11:57:05', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_27_05.png'),
(199, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == *[name=\'appSelect\']\n', '2020-02-14 11:59:30', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_29_30.png'),
(200, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 12:02:06', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_32_06.png'),
(201, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 12:02:13', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_32_13.png'),
(202, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 12:02:19', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_32_19.png'),
(203, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 12:02:26', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_32_26.png'),
(204, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 12:02:33', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_32_33.png'),
(205, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 12:02:40', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_32_40.png'),
(206, 'Facebook\\WebDriver\\Exception\\WebDriverCurlException', '7431276', '', '2020-02-14 12:02:54', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_32_54.png'),
(207, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with xpath == //*[@id=\"RecordSet\"]/tbody/tr[3]/td[1]\n', '2020-02-14 12:06:48', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_36_48.png'),
(208, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431276', 'Currently focused window has been closed.\n', '2020-02-14 12:08:52', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_38_52.png'),
(209, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431276', 'Window is closed\n', '2020-02-14 12:08:55', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_38_55.png'),
(210, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431276', 'Unable to get browser\n', '2020-02-14 12:09:52', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_39_52.png'),
(211, 'Facebook\\WebDriver\\Exception\\NoSuchWindowException', '7431276', 'Window is closed\n', '2020-02-14 12:09:55', 'Finacle Log Out Error', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_39_55.png'),
(212, 'Facebook\\WebDriver\\Exception\\NoSuchElementException', '7431276', 'Unable to find element with css selector == #userArea\n', '2020-02-14 12:13:12', 'EDIT CIFID1', 1, 'C:\\\\xampp\\\\htdocs\\\\hfc\\\\storage\\\\apps\\\\hfc\\\\screenshots\\\\7431276_2020_02_14_17_43_12.png');

-- --------------------------------------------------------

--
-- Table structure for table `bot_ip_logins`
--

CREATE TABLE `bot_ip_logins` (
  `id` int(10) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bot_process_dtl`
--

CREATE TABLE `bot_process_dtl` (
  `id` int(10) NOT NULL,
  `process_dtl_id` int(11) NOT NULL,
  `process_id` int(11) DEFAULT NULL,
  `process_dtl_desc` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bot_process_dtl`
--

INSERT INTO `bot_process_dtl` (`id`, `process_dtl_id`, `process_id`, `process_dtl_desc`) VALUES
(1, 1, 1, 'Login Process'),
(2, 2, 1, 'Data Entry Process'),
(3, 3, 1, 'Applicant Personal'),
(4, 4, 1, 'Applicant Personal Other Details'),
(5, 5, 1, 'Address'),
(6, 6, 1, 'Work Detail'),
(7, 7, 1, 'Income Expense'),
(8, 8, 1, 'Bank'),
(9, 9, 1, 'References'),
(10, 10, 1, 'Asset & Loan Details'),
(11, 11, 1, 'Other Charges'),
(12, 12, 1, 'Change Stage'),
(13, 13, 1, 'Pre-sanction'),
(15, 14, 1, 'Download Cibil'),
(16, 15, 1, 'Logout');

-- --------------------------------------------------------

--
-- Table structure for table `bot_process_mst`
--

CREATE TABLE `bot_process_mst` (
  `process_id` int(5) NOT NULL,
  `process_name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bot_process_mst`
--

INSERT INTO `bot_process_mst` (`process_id`, `process_name`) VALUES
(1, 'HFC login'),
(2, 'HFC CRM');

-- --------------------------------------------------------

--
-- Table structure for table `bot_rejected_apps`
--

CREATE TABLE `bot_rejected_apps` (
  `id` int(11) NOT NULL,
  `txtAppFormNo` varchar(20) NOT NULL,
  `remarks` varchar(500) NOT NULL,
  `ip_address` varchar(20) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `userId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bot_sequence_dtl`
--

CREATE TABLE `bot_sequence_dtl` (
  `seq_id` int(11) NOT NULL,
  `process_dtl_id` int(11) DEFAULT NULL,
  `seq_no` int(11) DEFAULT NULL,
  `selector_desc` varchar(45) DEFAULT NULL,
  `selector_type` varchar(45) DEFAULT NULL,
  `selector_id` varchar(500) DEFAULT NULL,
  `selector_value` varchar(1000) DEFAULT NULL,
  `default_value` varchar(1000) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `control_id` int(11) DEFAULT NULL,
  `isDel` int(1) DEFAULT NULL,
  `isSleep` int(11) DEFAULT 0,
  `parent_model` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bot_sequence_dtl`
--

INSERT INTO `bot_sequence_dtl` (`seq_id`, `process_dtl_id`, `seq_no`, `selector_desc`, `selector_type`, `selector_id`, `selector_value`, `default_value`, `model`, `control_id`, `isDel`, `isSleep`, `parent_model`) VALUES
(1, 1, 1, 'Website Login Link', 'href', '', 'https://ijprsunt7-04-ld18.icicibankltd.com:8212/SSO/ui/SSOLogin.jsp', '', '', 4, 0, 0, ''),
(2, 1, 2, 'Site Secure Link', 'id', 'moreInfoContainer', 'More information', '', '', 2, 0, 0, ''),
(3, 1, 3, 'Website Secure Link', 'id', 'overridelink', '', '', '', 2, 0, 0, ''),
(4, 1, 4, 'User ID Wait', 'id', 'usertxt', '', '', '', 8, 0, 0, ''),
(5, 1, 5, 'User ID', 'id', 'usertxt', 'HE000049', '', '', 1, 0, 0, ''),
(6, 1, 6, 'Password', 'id', 'passtxt', 'vikas@123', '', '', 1, 0, 0, ''),
(7, 1, 7, 'Login Button', 'id', 'Submit', '', '', '', 2, 0, 0, ''),
(8, 1, 8, 'Solution Select', 'name', '', 'appSelect', 'FINCORE', '', 3, 0, 0, ''),
(9, 1, 9, 'Accept Alert', '', '', '', '', '', 6, 0, 0, ''),
(10, 1, 10, 'Menu Shortcut', 'id', 'menuname', 'HOAACTD', '', '', 1, 0, 0, ''),
(11, 1, 11, 'CIF ID', 'id', 'sLnk2', 'javascript:shoCifId(objForm.CifId,\'ctrl\',\'F\',objForm.custName)', '', '', 13, 0, 0, ''),
(15, 2, 15, 'Solution Select', 'name', '', 'appSelect', 'CRM', '', 3, 0, 0, ''),
(16, 2, 16, 'Accept Alert', '', '', '', '', '', 6, 0, 0, ''),
(17, 2, 17, 'CIF Retail', 'id', 'spanFor1', '', '', '', 2, 0, 0, ''),
(18, 2, 18, 'New Entity', 'id', 'spanFor2', '', '', '', 2, 0, 0, ''),
(19, 2, 19, 'Customer', 'id', 'subviewspanFor20', '', '', '', 2, 0, 0, ''),
(20, 2, 20, 'Basic Info', 'name', '', 'AccountModBO.Gender', 'Male', '', 3, 0, 0, ''),
(21, 2, 21, 'Title', 'name', '', 'AccountModBO.Salution_code', '', '', 1, 0, 0, ''),
(22, 2, 22, 'First Name', 'name', '', 'AccountModBO.Cust_First_Name', '', '', 1, 0, 0, ''),
(23, 2, 23, 'Middle Name', 'name', '', 'AccountModBO.Cust_Middle_Name', '', '', 1, 0, 0, ''),
(24, 2, 24, 'Last Name', 'name', '', 'AccountModBO.Cust_Last_Name', '', '', 1, 0, 0, ''),
(25, 2, 25, 'Short Name', 'name', '', 'AccountModBO.Short_Name', '', '', 1, 0, 0, ''),
(26, 2, 26, 'Date Of Birth', 'name', '', '3_AccountB0.Cust_DOB', '', '', 1, 0, 0, ''),
(27, 1, 27, 'Minor Indicator', 'name', '', 'AccountModBO.CustomerMinor', 'N', '', 3, 0, 0, ''),
(28, 1, 28, 'Non-Resident Indicator', 'name', '', 'AccountModBO.CustomerNREFLG', 'N', '', 3, 0, 0, ''),
(29, 1, 29, 'Non-Resident Indicator', 'name', '', 'AccountModBO.StaffFlag', 'N', '', 3, 0, 0, ''),
(30, 1, 30, 'Availed Trade Services', 'name', '', 'AccountModBO.TFPartyFlag', 'N', '', 3, 0, 0, ''),
(31, 2, 31, 'Tax Deducted At Source', 'name', '', 'AccountB0.Tds_tbl', '', '', 1, 0, 0, ''),
(32, 1, 32, 'Purge Allowed', 'name', '', 'AccountModBO.PurgeFlag', 'N', '', 3, 0, 0, ''),
(33, 2, 33, 'Relationship Opening Date', 'name', '', '3_AccountB0.RelationshipOpeningDate', '', '', 1, 0, 0, ''),
(34, 1, 34, 'Save Button', 'name', 'saveBut', '', '', '', 2, 0, 0, ''),
(35, 1, 35, 'Tab Contact Detail', 'id', 'tab_tpageCont3', '', '', '', 2, 0, 0, ''),
(36, 1, 36, 'Mailing Address Click', 'class', 'sbttn', '', '', '', 2, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `city_data`
--

CREATE TABLE `city_data` (
  `id` int(11) NOT NULL,
  `short_city` varchar(255) NOT NULL,
  `city_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city_data`
--

INSERT INTO `city_data` (`id`, `short_city`, `city_name`) VALUES
(1, 'ABD', 'ABU DHABI'),
(2, 'ABO', 'ABOHAR'),
(3, 'ACG', 'ANCHORAGE'),
(4, 'ACH', 'ACHAMPATHU'),
(5, 'ACR', 'ACRA'),
(6, 'ADB', 'ADDIS ABABA'),
(7, 'ADL', 'ADELAIDE'),
(8, 'ADLI', 'ADILABAD'),
(9, 'ADM', 'AMSTERDAM'),
(10, 'ADN', 'ADEN'),
(11, 'ADO', 'ADONI'),
(12, 'ADR', 'ADOOR'),
(13, 'AGH', 'AZAMGARH'),
(14, 'AGR', 'AGRA'),
(15, 'AGT', 'AGARTALA'),
(16, 'AHD', 'AHMEDABAD'),
(17, 'AHMAD', 'AHMADNAGAR'),
(18, 'AIWL', 'AIZAWL'),
(19, 'AJR', 'AJMER'),
(20, 'AKA', 'ANAKAPALLI'),
(21, 'AKD', 'AUCKLAND'),
(22, 'AKO', 'AKOLA'),
(23, 'AL1', 'ALANGUDI'),
(24, 'ALA', 'ALAVAKKOTTAI'),
(25, 'ALAT', 'ALATHIOUR'),
(26, 'ALB', 'ALIBAUG'),
(27, 'ALD', 'ALLAHABAD'),
(28, 'ALDO', 'ALDONA'),
(29, 'ALG', 'ALONG'),
(30, 'ALI', 'ALIGARH'),
(31, 'ALM', 'ALMORA'),
(32, 'ALP', 'ALAPPUZHA'),
(33, 'ALR', 'ALWAR'),
(34, 'ALW', 'ALWAYE'),
(35, 'ALWA', 'ALWAYE/BANK JUNCTION'),
(36, 'AM1', 'AMARAVATHIPUDUR'),
(37, 'AM2', 'AMMAIYAPPAN'),
(38, 'AMA', 'AMARAVATI'),
(39, 'AMAR', 'AMBEDKAR NAGAR'),
(40, 'AMB', 'AMBALA'),
(41, 'AMH', 'AMROHA'),
(42, 'AMI', 'AMRELY'),
(43, 'AMK', 'AMBIKAPUR'),
(44, 'AML', 'AMALNER'),
(45, 'AMLI', 'AMRELI'),
(46, 'AMP', 'AMALAPURAM'),
(47, 'AMR', 'AMBUR'),
(48, 'AMRIT', 'AMRITSAR'),
(49, 'AMT', 'AMARAVATI'),
(50, 'AMTI', 'AMRAVATI'),
(51, 'ANA', 'ANANTHAPUR'),
(52, 'ANAG', 'ANANTNAG'),
(53, 'ANANT', 'ANANTPUR'),
(54, 'AND', 'ANAND'),
(55, 'ANG', 'ANGAMALY'),
(56, 'ANGUL', 'ANGUL'),
(57, 'ANJ', 'ANJUNA'),
(58, 'ANK', 'ANKALESHWAR'),
(59, 'ANNA', 'ANNAMALAI NAGAR'),
(60, 'ANNS', 'ANDAMANS'),
(61, 'ANR', 'AHMEDNAGAR'),
(62, 'ANUL', 'ANUGUL'),
(63, 'ANUP', 'ANUPPUR'),
(64, 'ANUR', 'ANANTAPUR'),
(65, 'AP', 'ANDRA PRADESH'),
(66, 'APM', 'ANGADIPURAM'),
(67, 'APY', 'ALLEPPEY'),
(68, 'APZ', 'AMBALAPUZHA'),
(69, 'ARA', 'ARANTANGI'),
(70, 'ARIA', 'ARARIA'),
(71, 'ARR', 'ARRAH'),
(72, 'ARUR', 'ARIYALUR'),
(73, 'ASAN', 'ASANSOL'),
(74, 'ASG', 'ASSAGAO'),
(75, 'ASN', 'ASSNORA'),
(76, 'ATE', 'A.THEKKUR'),
(77, 'ATH', 'ATHANI'),
(78, 'ATK', 'ATHIKKADI'),
(79, 'ATN', 'ATHENS'),
(80, 'ATR', 'ATTUR(SALEM DIST)'),
(81, 'AUC', 'AUCKLAND'),
(82, 'AUD', 'AURANGABAD'),
(83, 'AUYA', 'AURAIYA'),
(84, 'AVI', 'AVINIPPATTI'),
(85, 'AVN', 'AVINANGUDI'),
(86, 'AWP', 'ANTWERP'),
(87, 'AZL', 'AIZWAL'),
(88, 'BAAL', 'BANGALORE RURAL'),
(89, 'BAAM', 'BADGAM'),
(90, 'BAAN', 'BARDDHAMAN'),
(91, 'BAAR', 'BAGESHWAR'),
(92, 'BAAT', 'BALAGHAT'),
(93, 'BACH', 'BAHRAICH'),
(94, 'BAD', 'BADRINATH'),
(95, 'BADA', 'BANDA'),
(96, 'BADD', 'BADDI'),
(97, 'BADH', 'BAUDH'),
(98, 'BAG', 'BAGALKOTE'),
(99, 'BAGH', 'BAGHPAT'),
(100, 'BAH', 'BAHARAIN'),
(101, 'BAHA', 'BANAS KANTHA'),
(102, 'BAI', 'BARDOLI'),
(103, 'BAKA', 'BANKA'),
(104, 'BAL', 'BALANGIR'),
(105, 'BALA', 'BALASORE'),
(106, 'BALL', 'BALLIA'),
(107, 'BAM', 'BOMBOLIM'),
(108, 'BAMBO', 'BAMBOLIM, GOA'),
(109, 'BAN', 'BANGARAPET'),
(110, 'BANKA', 'BANKA (BIHAR)'),
(111, 'BAOT', 'BAGALKOT'),
(112, 'BAR', 'BARMER'),
(113, 'BARA', 'BANSWARA'),
(114, 'BARAM', 'BARAMATI'),
(115, 'BARBL', 'BARBIL'),
(116, 'BARH', 'BARGARH'),
(117, 'BARN', 'BARAN'),
(118, 'BAS', 'BASTI'),
(119, 'BAST', 'BASTORA'),
(120, 'BATA', 'BARPETA'),
(121, 'BATH', 'BATHINDA'),
(122, 'BAUR', 'BALRAMPUR'),
(123, 'BAV', 'BAVLA'),
(124, 'BAW', 'BARWANI'),
(125, 'BBG', 'BALLABH GARH'),
(126, 'BBN', 'BRISBANE'),
(127, 'BBNR', 'BHUBANESHWAR'),
(128, 'BBY', 'MUMBAI'),
(129, 'BCN', 'BARCELONA'),
(130, 'BCT', 'BUCHAREST'),
(131, 'BDA', 'BADAGARA'),
(132, 'BDD', 'BAGHDAD'),
(133, 'BDH', 'BHADOHI'),
(134, 'BDPR', 'BADLAPUR'),
(135, 'BDR', 'BIDAR'),
(136, 'BEA', 'BEUONOS AIRES'),
(137, 'BEG', 'BEGUSARAI'),
(138, 'BEL', 'BELLEVUE'),
(139, 'BENAU', 'BENAULIM- GOA'),
(140, 'BERH', 'BERHAMPUR ORISSA'),
(141, 'BET', 'BETUL'),
(142, 'BGD', 'BELGRADE'),
(143, 'BGGJ', 'BEGAMGANJ'),
(144, 'BGL', 'BEGULSARAI'),
(145, 'BGMP', 'BEGUMPET'),
(146, 'BGPR', 'BHAGALPUR'),
(147, 'BHA', 'BHARUCH'),
(148, 'BHAD', 'BHADRAVATI'),
(149, 'BHAK', 'BHADRAK'),
(150, 'BHAN', 'BHANJANAGAR, GANJAM DIST ORISSA'),
(151, 'BHD', 'BHANDARA'),
(152, 'BHG', 'BHANGAGARH'),
(153, 'BHGH', 'BAHADURGARH'),
(154, 'BHI', 'BHIND'),
(155, 'BHM', 'BAHARAMPUR'),
(156, 'BHOW', 'BHOWANIPORE'),
(157, 'BHPR', 'BHARATPUR'),
(158, 'BHR', 'BHAGALPUR'),
(159, 'BHU', 'BHUVANAGIRI'),
(160, 'BHUR', 'BHOJPUR'),
(161, 'BIC', 'BICHOLIM'),
(162, 'BICH', 'BICHOLIM'),
(163, 'BIID', 'BID'),
(164, 'BIJ', 'BIJAPUR'),
(165, 'BILL', 'BILLIMORA'),
(166, 'BIUM', 'BIRBHUM'),
(167, 'BIUR', 'BISHNUPUR'),
(168, 'BJG', 'BEIJING'),
(169, 'BJNR', 'BIJNOR'),
(170, 'BJP', 'BIJAPUR'),
(171, 'BKK', 'BANGKOK'),
(172, 'BKN', 'BIKANER'),
(173, 'BKRO', 'BOKARO'),
(174, 'BLAI', 'BHILAI'),
(175, 'BLE', 'BALESHWAR'),
(176, 'BLF', 'BELFAST'),
(177, 'BLGM', 'BELGAUM'),
(178, 'BLN', 'BERLIN'),
(179, 'BLPR', 'BILASPUR'),
(180, 'BLR', 'BULANDSHAHAR'),
(181, 'BLWR', 'BHILWARA'),
(182, 'BLY', 'BELLARY'),
(183, 'BMBAY', 'BOMBAY'),
(184, 'BMM', 'BIRMINGHAM'),
(185, 'BNA', 'BARNALA'),
(186, 'BNG', 'BANGALORE'),
(187, 'BNK', 'BANKURA'),
(188, 'BNR', 'BHUBANESWAR'),
(189, 'BOB', 'BOBLINGEN (GERMANY)'),
(190, 'BODI', 'BODINAYAKANUR'),
(191, 'BOL', 'BOLANGIR'),
(192, 'BOLE', 'BOLEPUR'),
(193, 'BOMD', 'BOMDILA'),
(194, 'BOON', 'BONGAIGAON'),
(195, 'BOR', 'BOISAR'),
(196, 'BPG', 'BHOPALGUNJ'),
(197, 'BPL', 'BHOPAL'),
(198, 'BPR', 'BHOZPUR'),
(199, 'BRAHM', 'BRAHMAWART COMM. CO.OP. BANK  KANPUR'),
(200, 'BRBNK', 'BARABANKI'),
(201, 'BRD', 'BARODA'),
(202, 'BRE', 'BARDEZ'),
(203, 'BRLY', 'BAREILLY'),
(204, 'BRPR', 'BERHAMPUR'),
(205, 'BRS', 'BARASAT'),
(206, 'BRU', 'BRUSSELS'),
(207, 'BRY', 'BARIELLY'),
(208, 'BSD', 'BASODA'),
(209, 'BSN', 'BOSTON'),
(210, 'BSR', 'BULSAR'),
(211, 'BTA', 'BHATINDA'),
(212, 'BUJ', 'BHUJJ'),
(213, 'BUL', 'BULDHANA'),
(214, 'BUN', 'BUNDI'),
(215, 'BUNA', 'BULDANA'),
(216, 'BUR', 'BURDWAN'),
(217, 'BURN', 'BURNPUR'),
(218, 'BUUN', 'BUDAUN'),
(219, 'BUX', 'BUXAR'),
(220, 'BVNR', 'BHAVNAGAR'),
(221, 'BWD', 'BHIWADI'),
(222, 'BWN', 'BHIWANI'),
(223, 'BYP', 'BEYPORE'),
(224, 'C5.88', 'FD INTEREST @5.88'),
(225, 'CAAR', 'CACHAR'),
(226, 'CAL', 'CALCUTTA'),
(227, 'CALA', 'CALANGUTE'),
(228, 'CAN', 'CANNANORE'),
(229, 'CAND', 'CANDOLIM'),
(230, 'CANS', 'CANSAULIM'),
(231, 'CAR', 'CARANZALEM'),
(232, 'CBE', 'COIMBATORE'),
(233, 'CBG', 'CAMBGIDGE'),
(234, 'CBR', 'CANBERRA'),
(235, 'CCN', 'KOCHI'),
(236, 'CCS', 'CARACAS'),
(237, 'CCUT', 'CALICUT'),
(238, 'CDB', 'CHIDAMBARAM'),
(239, 'CDP', 'CUDDAPPAH'),
(240, 'CDY', 'CHOWALLURPADY'),
(241, 'CEHI', 'CENTRAL DELHI'),
(242, 'CGH', 'CHITORGARH'),
(243, 'CGR', 'CHANDIGARH'),
(244, 'CHA', 'CHHAPRA'),
(245, 'CHAI', 'CHAMPHAI'),
(246, 'CHAR', 'CHAMARAJANAGAR'),
(247, 'CHAT', 'CHAMPAWAT'),
(248, 'CHBA', 'CHAMBA'),
(249, 'CHD', 'CHARKHI DADRI'),
(250, 'CHE', 'CHENNAI'),
(251, 'CHEL', 'CHANDEL'),
(252, 'CHGA', 'CHITRADURGA'),
(253, 'CHHI', 'CHHINDWARA'),
(254, 'CHI', 'CHITOOR'),
(255, 'CHIK', 'CHIKMAGALUR'),
(256, 'CHIT', 'CHITOOR'),
(257, 'CHK', 'CHAKAN'),
(258, 'CHLI', 'CHAMOLI'),
(259, 'CHN', 'CHURN'),
(260, 'CHNC', 'CHUNCHURA'),
(261, 'CHNG', 'CHANGLANG'),
(262, 'CHOT', 'CHITRAKOOT'),
(263, 'CHR', 'CHHATARPUR'),
(264, 'CHRA', 'CHATRA'),
(265, 'CHRH', 'CHITTAURGARH'),
(266, 'CHS', 'CHAS'),
(267, 'CHT', 'CHERTHALA'),
(268, 'CHTGG', 'CHITTAGONG'),
(269, 'CHU', 'CHURU'),
(270, 'CHUR', 'CHURACHANDPUR'),
(271, 'CHY', 'CHANGANACHERRY'),
(272, 'CKI', 'CHALAKUDY'),
(273, 'CKPT', 'CHILAKALURIPET'),
(274, 'CLB', 'COLOMBO, SRILANKA'),
(275, 'CND', 'CHINDWARA'),
(276, 'CNG', 'CHENGANNUR'),
(277, 'CNN', 'CANNANORE'),
(278, 'CNR', 'COONOOR'),
(279, 'COL', 'COLUMBUS'),
(280, 'COLV', 'COLVALE'),
(281, 'COT', 'COTONOU'),
(282, 'CPN', 'COPEN HAGEN'),
(283, 'CPR', 'CHANDRAPUR'),
(284, 'CPT', 'CAPE TOWN'),
(285, 'CRO', 'CAIRO'),
(286, 'CTG', 'CHITTAGONG'),
(287, 'CTH', 'CHRISTCHURCH'),
(288, 'CTK', 'CUTTACK'),
(289, 'CTP', 'CHATRAPATTI'),
(290, 'CUAH', 'CUDDAPAH'),
(291, 'CUD', 'CUDDALORE'),
(292, 'CVA', 'CHAVARA'),
(293, 'CWD', 'CHINCHWAD'),
(294, 'DABOL', 'DABOLIM, GOA'),
(295, 'DAD', 'DAHOD'),
(296, 'DADA', 'DANTEWADA'),
(297, 'DAH', 'DAHANU'),
(298, 'DAII', 'DATIA'),
(299, 'DAKS', 'DAKSHINA KANNADA'),
(300, 'DALI', 'DADRA & NAGAR HAVELI'),
(301, 'DAM', 'DAMAN'),
(302, 'DAMOH', 'DAMOH'),
(303, 'DANDE', 'DANDEWADA-PIN CODE - 494553 STATE - CHHATISGARH'),
(304, 'DANG', 'DARJILING'),
(305, 'DARE', 'DAVANAGERE'),
(306, 'DARR', 'DARRANG'),
(307, 'DAUR', 'DAKSHIN DINAJPUR'),
(308, 'DAUS', 'DAUSA'),
(309, 'DBD', 'DHANBAD'),
(310, 'DBH', 'DARBHANGA'),
(311, 'DBI', 'DOMBIVLI'),
(312, 'DBN', 'DURBAN'),
(313, 'DBR', 'DIBRUGARH'),
(314, 'DDN', 'DEHRADUN'),
(315, 'DEAR', 'DEOGHAR'),
(316, 'DEE', 'DEESA'),
(317, 'DERH', 'DEBAGARH'),
(318, 'DEV', 'DEVAKOTTAI(MAIN)'),
(319, 'DGL', 'DINDIGUL'),
(320, 'DGR', 'DAVANGERE'),
(321, 'DHA', 'DOHA'),
(322, 'DHAI', 'DHALAI'),
(323, 'DHAR', 'DHAR'),
(324, 'DHB', 'DHANBAD'),
(325, 'DHJI', 'DHEMAJI'),
(326, 'DHLE', 'DHULE'),
(327, 'DHM', 'DHARMAPURI'),
(328, 'DHP', 'DHARAPURAM'),
(329, 'DHR', 'DHARWAR'),
(330, 'DHRI', 'DHAMTARI'),
(331, 'DHUR', 'DHAULPUR'),
(332, 'DHW', 'DHARWAD'),
(333, 'DIA', 'DIAMOND HARBOUR'),
(334, 'DIEY', 'DIBANG VALLEY'),
(335, 'DIIU', 'DIU'),
(336, 'DIM', 'DIMAPUR'),
(337, 'DIRI', 'DINDORI'),
(338, 'DIS', 'DISA'),
(339, 'DISP', 'DISPUR'),
(340, 'DKA', 'DHAKKA'),
(341, 'DKB', 'CENTRALDELHIKAROLBAGH'),
(342, 'DL', 'DELHI'),
(343, 'DLA', 'DHULIA'),
(344, 'DLG', 'DARJEELING'),
(345, 'DLJ', 'DULIAJAN'),
(346, 'DMS', 'DHARAMSHALA'),
(347, 'DNK', 'DHENKANAL'),
(348, 'DOAD', 'DOHAD'),
(349, 'DOD', 'DODA'),
(350, 'DPR', 'DURGAPUR'),
(351, 'DRA', 'DEORIA'),
(352, 'DRJ', 'DHORAJI'),
(353, 'DRL', 'DEROL'),
(354, 'DRN', 'DHAHRAN'),
(355, 'DSM', 'DAR ES SALAM'),
(356, 'DTN', 'DALTENGANJ'),
(357, 'DUKA', 'DUMKA'),
(358, 'DURG', 'DURG'),
(359, 'DUUR', 'DUNGARPUR'),
(360, 'DVI', 'DEVIPATNAM'),
(361, 'DVK', 'DEVIKAPURAM'),
(362, 'DVL', 'DEOLALI'),
(363, 'DWS', 'DEWAS'),
(364, 'DXB', 'DUBAI'),
(365, 'EAAR', 'EAST NIMAR'),
(366, 'EAHI', 'EAST DELHI'),
(367, 'EALS', 'EAST GARO HILLS'),
(368, 'EANG', 'EAST KAMENG'),
(369, 'EARI', 'EAST GODAVARI'),
(370, 'EAST', 'EAST'),
(371, 'EDB', 'EDINBURG'),
(372, 'ELA', 'ELATHUR'),
(373, 'ELR', 'ELURU'),
(374, 'ELU', 'ELURU'),
(375, 'EMN', 'EDMONTON'),
(376, 'ERD', 'ERODE'),
(377, 'ERI', 'ERIYUR'),
(378, 'ERM', 'ERNAKULAM'),
(379, 'ETA', 'ETAH'),
(380, 'ETAH', 'ETAWAH'),
(381, 'ETR', 'ETTUMANOOR'),
(382, 'EVN', 'EDAVANNA'),
(383, 'FAAD', 'FATEHABAD'),
(384, 'FAIB', 'FATEHGARH SAHIB'),
(385, 'FAR', 'FARIDKOT'),
(386, 'FAUR', 'FATEHPUR'),
(387, 'FBD', 'FAIZABAD'),
(388, 'FER', 'FEROZEPUR'),
(389, 'FFT', 'FRANK FURT A/M'),
(390, 'FKBD', 'FARRUKHABAD'),
(391, 'FRD', 'FARIDABAD'),
(392, 'FRZ', 'FIROZABAD'),
(393, 'FTH', 'FATEHGARH'),
(394, 'FZR', 'FIROZPUR'),
(395, 'GAAG', 'GADAG'),
(396, 'GAAL', 'GARHWAL'),
(397, 'GAAM', 'GANJAM'),
(398, 'GAAR', 'GANGANAGAR'),
(399, 'GABU', 'GAUTAM BUDDHA NAGAR'),
(400, 'GALI', 'GADCHIROLI'),
(401, 'GAN', 'GANGAVATHI (KARNATAKA)'),
(402, 'GATI', 'GAJAPATI'),
(403, 'GAWA', 'GARHWA'),
(404, 'GAY', 'GAYA'),
(405, 'GBA', 'GULBARGA'),
(406, 'GBD', 'GHAZIABAD'),
(407, 'GDH', 'GIRIDIH'),
(408, 'GGK', 'GANGTOK'),
(409, 'GGN', 'GURGAON'),
(410, 'GHT', 'GAUHATI'),
(411, 'GHUR', 'GHAZIPUR'),
(412, 'GIL', 'GILGIT'),
(413, 'GNJ', 'GOPAL GANJ'),
(414, 'GNM', 'GANDHIDHAM'),
(415, 'GNOR', 'GANOUR'),
(416, 'GNR', 'GANDHINAGAR'),
(417, 'GNV', 'GENEVA'),
(418, 'GOA', 'GOA'),
(419, 'GOAT', 'GOLAGHAT'),
(420, 'GOB', 'GOBICHETTIPALAYAM'),
(421, 'GOBI', 'GOBICHETIPALAYAM'),
(422, 'GOD', 'GODHRA'),
(423, 'GODA', 'GODDA'),
(424, 'GON', 'GONDAL'),
(425, 'GONJ', 'GOPALGANJ'),
(426, 'GORA', 'GOALPARA'),
(427, 'GOYA', 'GONDIYA'),
(428, 'GPJ', 'GOPIGANJ'),
(429, 'GPR', 'GORAKHPUR'),
(430, 'GRN', 'GOREGAON'),
(431, 'GRNDA', 'GREATER NOIDA'),
(432, 'GRV', 'GURUVAYOOR'),
(433, 'GSG', 'GLASGOW'),
(434, 'GTR', 'GUNTUR'),
(435, 'GU', 'GUNA'),
(436, 'GUIR', 'GUIRIM'),
(437, 'GUL', 'GULBARGA'),
(438, 'GULA', 'GUMLA'),
(439, 'GULO', 'GULOATHI'),
(440, 'GUN', 'GUNTUR'),
(441, 'GUNT', 'GUNTAKAL'),
(442, 'GUR', 'GURDASPUR'),
(443, 'GWR', 'GWALIOR'),
(444, 'GZN', 'GIZAN'),
(445, 'HAAR', 'HARDWAR'),
(446, 'HADA', 'HARDA'),
(447, 'HADI', 'HAILAKANDI'),
(448, 'HAN', 'HANUMANGARH'),
(449, 'HANUM', 'HANUMANGARH'),
(450, 'HAO', 'HAORA'),
(451, 'HAOI', 'HARDOI'),
(452, 'HAR', 'HARIPAD'),
(453, 'HATH', 'HATHRAS'),
(454, 'HAV', 'HAVERI'),
(455, 'HAZ', 'HAZARIBAGH'),
(456, 'HGH', 'HOOGHLY'),
(457, 'HIAR', 'HISAR'),
(458, 'HILI', 'HINGOLI'),
(459, 'HIM', 'HIMMATNAGAR'),
(460, 'HJP', 'HAJIPUR'),
(461, 'HKG', 'HONGKONG'),
(462, 'HLD', 'HALDIA'),
(463, 'HLL', 'HALOL'),
(464, 'HMB', 'HAMBURG'),
(465, 'HMP', 'HAMIRPUR'),
(466, 'HNI', 'HANOI'),
(467, 'HNK', 'HANUMAKONDA (WARANGAL DT)'),
(468, 'HON', 'HOSHANGABAD'),
(469, 'HOO', 'HOOGHLY'),
(470, 'HOR', 'HOLALUR'),
(471, 'HOS', 'HOSUR'),
(472, 'HOW', 'HOWRAH'),
(473, 'HPR', 'HOSHIARPUR'),
(474, 'HPT', 'HOSPET'),
(475, 'HPU', 'HAPUR'),
(476, 'HSK', 'HELSINKI'),
(477, 'HSN', 'HASSAN'),
(478, 'HSR', 'HISSAR'),
(479, 'HUB', 'HUBLI'),
(480, 'HULI', 'HUGLI'),
(481, 'HUN', 'HUNUMAN NAGAR'),
(482, 'HWD', 'HINJAWADI'),
(483, 'HWH', 'HOWRAH'),
(484, 'HWN', 'HALDWANI'),
(485, 'HWR', 'HARIDWAR'),
(486, 'HYD', 'HYDERABAD'),
(487, 'HZB', 'HAZARIBAD'),
(488, 'IBD', 'ISLAMABAD'),
(489, 'ICH', 'ICHAPUR'),
(490, 'IDA', 'IDALYUR'),
(491, 'IDK', 'IDUKKI'),
(492, 'IDP', 'IDAPADI'),
(493, 'IJI', 'ICHALAKARANJI'),
(494, 'IJK', 'IRINJALAKUDA'),
(495, 'IMEA', 'IMPHAL EAST'),
(496, 'IMP', 'IMPHAL'),
(497, 'IMWE', 'IMPHAL WEST'),
(498, 'IND', 'INDORE'),
(499, 'IRN', 'IRINGA (TANZANIA)'),
(500, 'ITA', 'ITARSI'),
(501, 'ITARS', 'ITARSI'),
(502, 'ITB', 'ISTANBUL'),
(503, 'JAAR', 'JALANDHAR'),
(504, 'JAD', 'JADUGODA'),
(505, 'JAG', 'JAGATSINGHPUR'),
(506, 'JAGDL', 'JAGDALPUR-CHTTISGARH'),
(507, 'JAGRN', 'JAGRAON'),
(508, 'JAI', 'JAIPUR'),
(509, 'JAJA', 'JAJAPUR'),
(510, 'JALS', 'JAINTIA HILLS'),
(511, 'JAM', 'JAMNAGAR'),
(512, 'JAMSH', 'JAMSHEDPUR'),
(513, 'JAN', 'JANGAREDDYGUDEM'),
(514, 'JAOR', 'JALOR'),
(515, 'JAPA', 'JANJGIR - CHAMPA'),
(516, 'JAU', 'JAUNPUR'),
(517, 'JAUI', 'JAMUI'),
(518, 'JAUN', 'JALAUN'),
(519, 'JAUR', 'JAGATSINGHAPUR'),
(520, 'JBL', 'JABALPUR'),
(521, 'JDD', 'JEDDAH'),
(522, 'JEAD', 'JEHANABAD'),
(523, 'JEYP', 'JEYPORE'),
(524, 'JGH', 'JUNAGADH'),
(525, 'JGN', 'JALGAON'),
(526, 'JHA', 'JHARIA'),
(527, 'JHAR', 'JHAJJAR'),
(528, 'JHB', 'JOHANNESBURG'),
(529, 'JHR', 'JHARSUGUDA'),
(530, 'JHUA', 'JHABUA'),
(531, 'JHUN', 'JHUNJHUNUN'),
(532, 'JHW', 'JHALAWAR'),
(533, 'JIN', 'JIND'),
(534, 'JKT', 'JAKARTA'),
(535, 'JLN', 'JALNA'),
(536, 'JLR', 'JULLUNDUR'),
(537, 'JMU', 'JAMMU'),
(538, 'JNS', 'JHANSI'),
(539, 'JNU', 'JHUNJHUNU'),
(540, 'JODA', 'JODA'),
(541, 'JOR', 'JORHAT'),
(542, 'JOWA', 'JOWAT, MEGHALAYA PINCODE: 793150'),
(543, 'JPG', 'JALPAIGURI'),
(544, 'JPR', 'JODHPUR'),
(545, 'JSL', 'JAISALMER'),
(546, 'JYAR', 'JYOTIBA PHULE NAGAR'),
(547, 'KAA', 'KADI'),
(548, 'KAAL', 'KAITHAL'),
(549, 'KAAM', 'KANCHEEPURAM'),
(550, 'KAAR', 'KANPUR NAGAR'),
(551, 'KAAT', 'KANPUR DEHAT'),
(552, 'KABI', 'KAUSHAMBI'),
(553, 'KAD', 'KUMBANAD'),
(554, 'KADI', 'KALAHANDI'),
(555, 'KAER', 'KANKER'),
(556, 'KAG', 'KARIM NAGAR'),
(557, 'KAHA', 'KAWARDHA'),
(558, 'KAHH', 'KACHCHH'),
(559, 'KAI', 'KARAIKUDI'),
(560, 'KAIL', 'KARGIL'),
(561, 'KAL', 'KALYAN'),
(562, 'KALA', 'KALAMASSERY'),
(563, 'KALI', 'KARAULI'),
(564, 'KALO', 'KALOL'),
(565, 'KAN', 'KANPUR'),
(566, 'KAND', 'KANDHAMAL'),
(567, 'KANG', 'KARBI ANGLONG'),
(568, 'KANJ', 'KARIMGANJ'),
(569, 'KANR', 'KANNUR'),
(570, 'KAOD', 'KASARAGOD'),
(571, 'KAP', 'KAPURTHALA'),
(572, 'KAR', 'KANNUR'),
(573, 'KARA', 'KARAD'),
(574, 'KARI', 'KANNIYAKUMARI'),
(575, 'KAS', 'KASARGOD'),
(576, 'KAT', 'KATTAPANA'),
(577, 'KAUA', 'KAIMUR (BHABUA)'),
(578, 'KAUJ', 'KANNAUJ'),
(579, 'KAUP', 'KAMRUP'),
(580, 'KAV', 'KAVALKINARU'),
(581, 'KAWA', 'KAWARDHA'),
(582, 'KAY', 'KAYAMKULAM'),
(583, 'KBL', 'KABUL'),
(584, 'KDA', 'KANDAVARAYANPATTI'),
(585, 'KDI', 'KADI'),
(586, 'KDK', 'KODAIKANAL'),
(587, 'KDL', 'KANDLA'),
(588, 'KEAR', 'KENDUJHAR'),
(589, 'KEE', 'KEERANUR'),
(590, 'KEL', 'KEELAVALAVU'),
(591, 'KEO', 'KEONJHAR'),
(592, 'KERA', 'KENDRAPARA'),
(593, 'KEV', 'KEVADIA'),
(594, 'KGD', 'KANHANGAD'),
(595, 'KGM', 'KOTHAGUDEM'),
(596, 'KHA', 'KHANDWA'),
(597, 'KHA01', 'KHARGONE'),
(598, 'KHAJ', 'KHAJURAHO'),
(599, 'KHAM', 'KHAMMAM'),
(600, 'KHAR', 'KHARAGPUR'),
(601, 'KHD', 'KHEDA'),
(602, 'KHHA', 'KHORDHA'),
(603, 'KHIA', 'KHAGARIA'),
(604, 'KHN', 'KHANNA'),
(605, 'KHP', 'KHAPOLI'),
(606, 'KHR', 'KHURDA'),
(607, 'KHRI', 'KHERI'),
(608, 'KHU', 'KHURZA'),
(609, 'KINJ', 'KISHANGANJ'),
(610, 'KIUR', 'KINNAUR'),
(611, 'KJT', 'KARJAT'),
(612, 'KKA', 'KOTTARAKKARA'),
(613, 'KKD', 'KOZHIKODE'),
(614, 'KKI', 'KANYA KUMARI'),
(615, 'KKM', 'KUMBAKONAM'),
(616, 'KKN', 'KAKINADA'),
(617, 'KKR', 'KURUKSHETRA'),
(618, 'KKUDI', 'KARAIKUDI'),
(619, 'KL1', 'KOLLIDAM'),
(620, 'KLA', 'KEELAVALAVU'),
(621, 'KLD', 'KADALADI'),
(622, 'KLK', 'KILAKKARAI'),
(623, 'KLL', 'KALLAL'),
(624, 'KLM', 'KOLLAM'),
(625, 'KLML', 'KULLU MANALI'),
(626, 'KLP', 'KUALALAMPUR'),
(627, 'KLPR', 'KOLHAPUR'),
(628, 'KLR', 'KOLAR'),
(629, 'KLY', 'KOLENCHERRY'),
(630, 'KMD', 'KATHMANDU'),
(631, 'KMM', 'KOTHAMANGALAM'),
(632, 'KMR', 'KASHMIR'),
(633, 'KNA', 'KAIRANA'),
(634, 'KND', 'KANDANUR'),
(635, 'KNE', 'KONERIRAJAPURAM'),
(636, 'KNI', 'KONNI'),
(637, 'KNK', 'KUNNAMKULAM'),
(638, 'KNL', 'KARNAL'),
(639, 'KNP', 'KARUNAGAPPALLY'),
(640, 'KNR', 'CORRIM NAGAR'),
(641, 'KNRK', 'KONARAK'),
(642, 'KOAL', 'KOPPAL'),
(643, 'KOAR', 'KOCH BIHAR'),
(644, 'KOC', 'KOCHI'),
(645, 'KOD', 'KODMUDI'),
(646, 'KOGU', 'KODAGU'),
(647, 'KOHIM', 'KOHIMA- NAGALAND'),
(648, 'KOIB', 'KOLASIB'),
(649, 'KOL', 'KOLKATA'),
(650, 'KOLM', 'KOLLAM'),
(651, 'KOM', 'KOMARATCHI'),
(652, 'KOMA', 'KODARMA'),
(653, 'KON', 'KONAPET'),
(654, 'KOO', 'KOOTHANALLUR'),
(655, 'KOP', 'KOLHAPUR'),
(656, 'KOPA', 'KOPPANAPATTI'),
(657, 'KOR', 'KORBA'),
(658, 'KORP', 'KORAPUT'),
(659, 'KOT', 'KOTA'),
(660, 'KOYA', 'KORIYA'),
(661, 'KPL', 'KAMPALA'),
(662, 'KPM', 'KANCHIPURAM'),
(663, 'KPP', 'KAPURTHALA'),
(664, 'KPT', 'KALPETTA'),
(665, 'KPY', 'KANJIRAPPALLY'),
(666, 'KRA', 'KAIRA'),
(667, 'KRC', 'KARACHI'),
(668, 'KRI', 'KRISHNA'),
(669, 'KRMR', 'KARIMNAGAR'),
(670, 'KRNL', 'KURNOOL'),
(671, 'KRR', 'KARUR'),
(672, 'KSY', 'KALAMASSERY'),
(673, 'KTA', 'KOTA'),
(674, 'KTH', 'KATIHAR'),
(675, 'KTM', 'KOTTAYAM'),
(676, 'KTN', 'KATNI'),
(677, 'KTP', 'KOTTAIPATTINAM'),
(678, 'KTT', 'KOTTAYAM'),
(679, 'KTY', 'KOTTAIYUR'),
(680, 'KUAR', 'KUSHINAGAR'),
(681, 'KUL', 'KULPIRAI'),
(682, 'KULU', 'KULLU'),
(683, 'KUN', 'KUNNAMANGALAM'),
(684, 'KUR', 'KUMARAVELUR'),
(685, 'KURA', 'KUPWARA'),
(686, 'KURN', 'KURNOOL'),
(687, 'KUS', 'KUSHALNAGAR'),
(688, 'KUT', 'KUTTIPPURAM'),
(689, 'KWT', 'KUWAIT'),
(690, 'KYL', 'KAYALPATTINAM'),
(691, 'KYM', 'KAYAMKULAM'),
(692, 'KZD', 'KAZARGODE'),
(693, 'KZY', 'KOZHENCHERRY'),
(694, 'LAAI', 'LAKHISARAI'),
(695, 'LAEP', 'LAKSHADWEEP'),
(696, 'LAGOS', 'LAGOS'),
(697, 'LAL', 'LASALGAON'),
(698, 'LAS', 'LOS ANGELES'),
(699, 'LAT', 'LATUR'),
(700, 'LATI', 'LAHUL & SPITI'),
(701, 'LAUR', 'LAKHIMPUR'),
(702, 'LBN', 'LISBON'),
(703, 'LDN', 'LUDHIANA'),
(704, 'LEH)', 'LEH (LADAKH)'),
(705, 'LOH', 'LOHARDAGA'),
(706, 'LOIT', 'LOHIT'),
(707, 'LON', 'LONDON'),
(708, 'LONV', 'LONAVALA'),
(709, 'LORI', 'LOWER SUBANSIRI'),
(710, 'LPT', 'LALPET'),
(711, 'LSK', 'LUSAKA'),
(712, 'LUCK', 'LUCKNOW'),
(713, 'LUD', 'LUDHIANA'),
(714, 'LUEI', 'LUNGLEI'),
(715, 'MAA', 'MANDI'),
(716, 'MAAH', 'MALDAH'),
(717, 'MAAM', 'MALAPPURAM'),
(718, 'MAAR', 'MAHBUBNAGAR'),
(719, 'MAAU', 'MAU'),
(720, 'MABA', 'MAHOBA'),
(721, 'MADHU', 'MADHUPUR'),
(722, 'MADI', 'MADIKERI'),
(723, 'MAG', 'MANDI GOBINDGARH'),
(724, 'MAH', 'MAHINDER GARH'),
(725, 'MAHE', 'MAHE'),
(726, 'MAI', 'MANDI'),
(727, 'MAIT', 'MAMIT'),
(728, 'MAKN', 'MAKRANA'),
(729, 'MAL', 'MALAPURAM'),
(730, 'MALA', 'MANDLA'),
(731, 'MALD', 'MALDA TOWN'),
(732, 'MAMP', 'MAMALLAPURAM'),
(733, 'MAN', 'MANILA'),
(734, 'MANA', 'MAHESANA'),
(735, 'MAND', 'MANDYA'),
(736, 'MANJ', 'MAHRAJGANJ'),
(737, 'MANJR', 'MANJERI'),
(738, 'MAON', 'MARIGAON'),
(739, 'MAP', 'MAPUCA'),
(740, 'MAR', 'MARGAO'),
(741, 'MARA', 'MADHEPURA'),
(742, 'MARH', 'MAHENDRAGARH'),
(743, 'MARI', 'MAINPURI'),
(744, 'MAS', 'MANSA'),
(745, 'MAT', 'MATHURA'),
(746, 'MBD', 'MORADABAD'),
(747, 'MBN', 'MADHUBANI'),
(748, 'MBW', 'MAHABALESHWAR'),
(749, 'MCN', 'MUNICH'),
(750, 'MCW', 'MOSCOW'),
(751, 'MDB', 'MURSHIDABAD'),
(752, 'MDD', 'MADRID'),
(753, 'MDM', 'MANDORE MANDI'),
(754, 'MDR', 'MUNDUR'),
(755, 'MDS', 'CHENNAI'),
(756, 'MDU', 'MADURAI'),
(757, 'ME', 'MIRA ROAD(E)'),
(758, 'MEAK', 'MEDAK'),
(759, 'MEH', 'MEHSANA'),
(760, 'MEL', 'MELASTVAPURI'),
(761, 'MER', 'MERCES'),
(762, 'MEUR', 'MEDINIPUR'),
(763, 'MGD', 'MANNARGUDI'),
(764, 'MGG', 'MANDI GOBIND GARH'),
(765, 'MGO', 'MANNARGUDI'),
(766, 'MHD', 'MAHAD'),
(767, 'MHI', 'MAHIBALANPATTI'),
(768, 'MHOW', 'MHOW-MP'),
(769, 'MIAMI', 'MIAMI,FLORIDA'),
(770, 'MIC', 'MICHIGAN'),
(771, 'MID', 'MIDNAPUR'),
(772, 'MIG', 'MIG CITY CODE'),
(773, 'MIL', 'MILAN'),
(774, 'MIUR', 'MIRZAPUR'),
(775, 'MLI', 'MALLIKAPURAM'),
(776, 'MLK', 'MELANIKULIKUDIKADU'),
(777, 'MLP', 'MELAPAVOOR'),
(778, 'MLR', 'MELOLAKKUR'),
(779, 'MLU', 'MELUR'),
(780, 'MLY', 'MALAIYUR'),
(781, 'MNG', 'MANGALORE'),
(782, 'MNR', 'MUNNAR'),
(783, 'MOGA', 'MOGA'),
(784, 'MOH', 'MOHALI'),
(785, 'MOL', 'MOHALI'),
(786, 'MONA', 'MORENA'),
(787, 'MONG', 'MOKOKCHUNG'),
(788, 'MOON', 'MON'),
(789, 'MPL', 'MANIPAL'),
(790, 'MPZ', 'MUVATTUPUZHA'),
(791, 'MRS', 'MAURITIUS'),
(792, 'MRT', 'MEERUT'),
(793, 'MRY', 'MATTANCHERY'),
(794, 'MSD', 'MANDSAUR'),
(795, 'MSL', 'MARSEILLES'),
(796, 'MST', 'MUSCAT'),
(797, 'MSU', 'MASERU'),
(798, 'MTL', 'MONTREAL'),
(799, 'MUA', 'MUMBAI - ANDHERI'),
(800, 'MUAR', 'MUKTSAR'),
(801, 'MUF', 'MUZZAFARNAGAR'),
(802, 'MUN', 'MUNGER'),
(803, 'MUN)', 'MUMBAI (SUBURBAN)'),
(804, 'MUR', 'MURAIYUR'),
(805, 'MUS', 'MUSSOORIE'),
(806, 'MUT', 'MUTHUPET'),
(807, 'MUZ', 'MUZAFFARABAD'),
(808, 'MUZA', 'MUZAFFARNAGAR'),
(809, 'MVK', 'MAVELIKKARA'),
(810, 'MXC', 'MEXICO'),
(811, 'MYD', 'MAYILADUTHURAI'),
(812, 'MYS', 'MYSORE'),
(813, 'MZPR', 'MUZAFFARPUR'),
(814, 'MZR', 'MUZAFFAR NAGAR'),
(815, 'NAAR', 'NANDURBAR'),
(816, 'NAC', 'NACHANDUPATI'),
(817, 'NADA', 'NALANDA'),
(818, 'NAG', 'NAGDA'),
(819, 'NAGA', 'NAGAPATTINAM'),
(820, 'NAGN', 'NAGAON'),
(821, 'NAGU', 'NAGAUR'),
(822, 'NAIK', 'NASHIK'),
(823, 'NALD', 'NACHINOLA-ALDONA'),
(824, 'NALE', 'NALASOPARA(E)'),
(825, 'NALW', 'NALASOPARA(W)'),
(826, 'NAM', 'NAMAKKAL'),
(827, 'NAR', 'NARNAUL'),
(828, 'NARH', 'NAYAGARH'),
(829, 'NARI', 'NALBARI'),
(830, 'NARM', 'NARMADA'),
(831, 'NARS', 'NARSIMHAPUR'),
(832, 'NARSI', 'NARSINGHPUR'),
(833, 'NAT', 'NATTARASANKOTTAI'),
(834, 'NAUR', 'NABARANGAPUR'),
(835, 'NAVM', 'NAVI MUMBAI'),
(836, 'NAWA', 'NAWADA'),
(837, 'NBH', 'NABHA'),
(838, 'NBR', 'NILAMBUR'),
(839, 'ND', 'NEW DELHI'),
(840, 'NDA', 'NADIA'),
(841, 'NDD', 'NEDUMANGAD'),
(842, 'NDIAD', 'NADIAD'),
(843, 'NECH', 'NEEMUCH'),
(844, 'NEM', 'NEMATHANPATTI'),
(845, 'NESS', 'NESSAI'),
(846, 'NEWBO', 'NEW BOMBAY'),
(847, 'NEWMU', 'NEW MUMBAI'),
(848, 'NEY', 'NEYVELI'),
(849, 'NGL', 'NAGERCOIL'),
(850, 'NIP', 'NIPANI'),
(851, 'NIRS', 'NICOBARS'),
(852, 'NJY', 'NEW JERSEY'),
(853, 'NLG', 'NALGONDA'),
(854, 'NLI', 'NELLAYI'),
(855, 'NLR', 'NELLORE'),
(856, 'NMM', 'NEMOM'),
(857, 'NND', 'NANDED'),
(858, 'NNT', 'NAINITAL'),
(859, 'NOC', 'NEW ORLEANS'),
(860, 'NOEA', 'NORTH EAST DELHI'),
(861, 'NOHI', 'NORTH DELHI'),
(862, 'NOI', 'NOIDA'),
(863, 'NOL', 'NEW ORLEANS'),
(864, 'NOLS', 'NORTH CACHAR HILLS'),
(865, 'NOOA', 'NORTH GOA'),
(866, 'NORA', 'NORTH TRIPURA'),
(867, 'NOTH', 'NORTH'),
(868, 'NOW', 'NOWGONG'),
(869, 'NOWE', 'NORTH WEST DELHI'),
(870, 'NPR', 'NAGPUR'),
(871, 'NPRR', 'NORTH PARUR'),
(872, 'NRB', 'NAIROBI'),
(873, 'NRT', 'NAZRETH'),
(874, 'NSK', 'NASIK'),
(875, 'NSR', 'NAVSARI'),
(876, 'NSRB', 'NASIRABAD'),
(877, 'NSW', 'NEW SOUTH WALES'),
(878, 'NUDA', 'NUAPADA'),
(879, 'NUR', 'NURMAHAL'),
(880, 'NWNC', 'NW NORTH CANTON OH-44720 USA'),
(881, 'NWR', 'NAWANSHAHR'),
(882, 'NYJ', 'NEW JERSEY'),
(883, 'NYK', 'NEW YORK'),
(884, 'NZD', 'NIZAMABAD'),
(885, 'OKH', 'OKHA'),
(886, 'OLU', 'OLLUR'),
(887, 'ONG', 'ONGOLE'),
(888, 'ORA', 'ORATHUR'),
(889, 'OREWA', 'OREWA'),
(890, 'OS', 'OSLO'),
(891, 'OSI', 'O.SIRUVAYAL'),
(892, 'OSK', 'OSAKA'),
(893, 'OSMN', 'OSMANABAD'),
(894, 'OTW', 'OTTAWA'),
(895, 'OTY', 'OOTY/OTACAMUND'),
(896, 'PAAD', 'PALAKKAD'),
(897, 'PAAN', 'PASHCHIM CHAMPARAN'),
(898, 'PAG', 'PAGANERI'),
(899, 'PAL', 'PALANPUR'),
(900, 'PALAN', 'PALANI'),
(901, 'PALI', 'PALI'),
(902, 'PALS', 'PANCH MAHALS'),
(903, 'PAMU', 'PALAMU'),
(904, 'PAN', 'PANCHKULA'),
(905, 'PANA', 'PANNA'),
(906, 'PANC', 'PANCHKULA'),
(907, 'PANI', 'PARBHANI'),
(908, 'PANJ', 'PANJIM'),
(909, 'PANJI', 'PANJIM'),
(910, 'PANV', 'PANVEL'),
(911, 'PAP', 'PAPUA'),
(912, 'PAR', 'PARIS'),
(913, 'PARE', 'PAPUM PARE'),
(914, 'PAT', 'PATIALA'),
(915, 'PATAN', 'PATAN'),
(916, 'PATHA', 'PATHANAMTHITTA'),
(917, 'PAU', 'PAURI'),
(918, 'PAUM', 'PASHCHIMI SINGHBHUM'),
(919, 'PAUR', 'PAKAUR'),
(920, 'PBR', 'PORBANDAR'),
(921, 'PCH', 'PONDICHERRY'),
(922, 'PCT', 'PATHANCOT'),
(923, 'PDCY', 'PUDUCHERRY'),
(924, 'PDP', 'PARADEEP'),
(925, 'PDR', 'PEDDUR'),
(926, 'PED', 'PEDNE'),
(927, 'PEN', 'PENNSYLVANIA'),
(928, 'PER', 'PERALAM'),
(929, 'PERN', 'PERINTALMANNA'),
(930, 'PEUR', 'PERAMBALUR'),
(931, 'PEZ', 'PEROZEPUR'),
(932, 'PGG', 'PATALGANGA'),
(933, 'PGH', 'PITHORA GARH'),
(934, 'PGL', 'PAURI GAZHUAL'),
(935, 'PGR', 'PALGHAR'),
(936, 'PGT', 'PALGHAT'),
(937, 'PHA', 'PHAGWARA'),
(938, 'PHEK', 'PHEK'),
(939, 'PHIL', 'PHILADELPHIA'),
(940, 'PIL', 'PILIBHIT'),
(941, 'PILE', 'PILERNE'),
(942, 'PIRH', 'PITHORAGARH'),
(943, 'PJM', 'PANAJI'),
(944, 'PJR', 'PINJORE'),
(945, 'PKL', 'PANCHKULA'),
(946, 'PKR', 'POKARAN'),
(947, 'PLA', 'P.ALAGAPURI'),
(948, 'PLG', 'PALAVANGUDI'),
(949, 'PLI', 'PALAI'),
(950, 'PLK', 'PULANKURICHI'),
(951, 'PLM', 'POOLAMPATTI'),
(952, 'PLN', 'PILANI'),
(953, 'PLR', 'PUNALUR'),
(954, 'PLU', 'PERIYAKULAM'),
(955, 'PLY', 'PULIYUR'),
(956, 'PM', 'PEN'),
(957, 'PMD', 'PATTAMADAI'),
(958, 'PMK', 'PARAMAKUDI'),
(959, 'PMV', 'PONNAMARAVATHI'),
(960, 'PN', 'PONDA'),
(961, 'PNA', 'PATHANAMTHITTA'),
(962, 'PNK', 'PANAIKULAM'),
(963, 'PNM', 'PANAMA CITY'),
(964, 'PNR', 'PAYYANNUR'),
(965, 'POL', 'POLLACHI'),
(966, 'PON', 'PONDA'),
(967, 'POP', 'PONPETHI'),
(968, 'POR', 'PORVORIM'),
(969, 'PPT', 'PANIPAT'),
(970, 'PRAM', 'PRAKASAM'),
(971, 'PRDT', 'PRODDATUR'),
(972, 'PRG', 'PARAGANAS'),
(973, 'PRGH', 'PRATAPGARH'),
(974, 'PRM', 'PERUMBAVOOR'),
(975, 'PRR', 'PARAVOOR'),
(976, 'PRS', 'PARIS'),
(977, 'PRT', 'PORTONOVO'),
(978, 'PRTB', 'PARTABPUR'),
(979, 'PTBR', 'PORT BLAIR'),
(980, 'PTH', 'PERTH'),
(981, 'PTM', 'PATTAMBI'),
(982, 'PTN', 'PATNA'),
(983, 'PTR', 'PRETORIA'),
(984, 'PTU', 'PATTUKOTTAI'),
(985, 'PUAI', 'PUDUKKOTTAI'),
(986, 'PUAN', 'PURBA CHAMPARAN'),
(987, 'PUCH', 'PUNCH'),
(988, 'PUD', 'PUDUKOTTAI'),
(989, 'PUL', 'PULMAMIDI'),
(990, 'PUMA', 'PULWAMA'),
(991, 'PUNE', 'PUNE'),
(992, 'PUR', 'PURULIA'),
(993, 'PURA', 'PURNIA'),
(994, 'PURI', 'PURI'),
(995, 'PUUM', 'PURBI SINGHBHUM'),
(996, 'PUYA', 'PURULIYA'),
(997, 'PVM', 'PIRAVOM'),
(998, 'PVT', 'PAVITHRAM'),
(999, 'PWL', 'PALWAL'),
(1000, 'QBC', 'QUEBEC'),
(1001, 'QLN', 'QUILON'),
(1002, 'RAAM', 'RAMANATHAPURAM'),
(1003, 'RADA', 'RAYAGADA'),
(1004, 'RADI', 'RANGAREDDI'),
(1005, 'RAEN', 'RAISEN'),
(1006, 'RAG', 'RAMGARH'),
(1007, 'RAH', 'RAMGANH MANDI'),
(1008, 'RAIG', 'RAIGARH'),
(1009, 'RAIR', 'RAIRANGPUR'),
(1010, 'RAJ', 'RAJULA'),
(1011, 'RAJG', 'RAJGARH'),
(1012, 'RAK', 'RAS AL KHAIMAH'),
(1013, 'RALI', 'RAE BARELI'),
(1014, 'RAM', 'RAMPUR'),
(1015, 'RAN', 'RANCHI'),
(1016, 'RAND', 'RAJSAMAND'),
(1017, 'RANI', 'RANIGANJ'),
(1018, 'RARH', 'RAIGARH'),
(1019, 'RARI', 'RAJAURI'),
(1020, 'RASAG', 'RASAGOBINDAPUR'),
(1021, 'RAT', 'RATLAM'),
(1022, 'RAV', 'RAVANASAMUDRAM'),
(1023, 'RAY', 'RAYAVARAM'),
(1024, 'RBY', 'RAE BAREILLY'),
(1025, 'RCP', 'RAMACHANDRAPURAM'),
(1026, 'RCR', 'RAICHUR'),
(1027, 'RDJ', 'RIO DE JANEIRO'),
(1028, 'RED', 'REDDIARCHATRAM'),
(1029, 'REW', 'REWARI'),
(1030, 'RFW', 'RENFREW , U.K'),
(1031, 'RGD', 'RAIGAD'),
(1032, 'RGM', 'RAMAGUNDAM'),
(1033, 'RGR', 'RATNAGIRI'),
(1034, 'RIOI', 'RI BHOI'),
(1035, 'RJK', 'RAJKOT'),
(1036, 'RJNDG', 'RAJNANDGAON'),
(1037, 'RJP', 'RAJPURA'),
(1038, 'RJR', 'RAJAMUNDRY'),
(1039, 'RKE', 'ROORKEE'),
(1040, 'RKL', 'ROURKELA'),
(1041, 'RKS', 'RISHIKESH'),
(1042, 'RMA', 'ROMA  ITALY'),
(1043, 'RME', 'ROME'),
(1044, 'RMN', 'REMUNA'),
(1045, 'RMP', 'RAMPUR'),
(1046, 'RMPR', 'RAMANATHAPURA'),
(1047, 'RMT', 'RAMAPATTINAM'),
(1048, 'RND', 'RANGA REDDY'),
(1049, 'RNG', 'RANGIEM'),
(1050, 'ROAS', 'ROHTAS'),
(1051, 'ROH', 'ROHA'),
(1052, 'ROP', 'ROPAR'),
(1053, 'RPM', 'RAJALPALAYAM'),
(1054, 'RPR', 'RAIPUR'),
(1055, 'RPT', 'RANIPET'),
(1056, 'RTK', 'ROHTAK'),
(1057, 'RUAG', 'RUDRAPRAYAG'),
(1058, 'RUAR', 'RUPNAGAR'),
(1059, 'RUD', 'RUDRAPUR'),
(1060, 'RWA', 'REWA'),
(1061, 'RWR', 'RIWARI'),
(1062, 'RYD', 'RIYADH'),
(1063, 'RYJ', 'RYEKJAVIK'),
(1064, 'SAA', 'SATNA'),
(1065, 'SAAN', 'SARAN'),
(1066, 'SAAR', 'SANT KABIR NAGAR'),
(1067, 'SAF', 'SAFAT'),
(1068, 'SAGAR', 'SAGAR'),
(1069, 'SAHA', 'SABAR KANTHA'),
(1070, 'SAHI', 'SANT RAVIDAS NAGAR BHADOHI'),
(1071, 'SAJ', 'SAN JOSE'),
(1072, 'SALC', 'SALCETE - GOA STATE'),
(1073, 'SAM', 'SAMAYNALLUR'),
(1074, 'SAMR', 'SAMBALPUR'),
(1075, 'SAN', 'SANGOLDA'),
(1076, 'SANG', 'SANGRUR'),
(1077, 'SANJ', 'SAHIBGANJ'),
(1078, 'SANQ', 'SANQUELIM'),
(1079, 'SANTA', 'SANTACRUZ'),
(1080, 'SAS', 'SASARAM'),
(1081, 'SASA', 'SAHARSA'),
(1082, 'SASR', 'SAHARSA'),
(1083, 'SAT', 'SATARA'),
(1084, 'SATNA', 'SATNA'),
(1085, 'SAUR', 'SAWAI MADHOPUR'),
(1086, 'SBD', 'SAHIBABAD'),
(1087, 'SBK', 'SABARKANTHA'),
(1088, 'SDI', 'SIDHI'),
(1089, 'SEC', 'SECUNDERABAD'),
(1090, 'SEH', 'SEHORE'),
(1091, 'SEIP', 'SERCHHIP'),
(1092, 'SEN', 'SENDWHA'),
(1093, 'SEONI', 'SEONI'),
(1094, 'SETI', 'SENAPATI'),
(1095, 'SFC', 'SAN FRANCISCO'),
(1096, 'SGN', 'SRIGANGANAGAR'),
(1097, 'SGP', 'SINGAPORE'),
(1098, 'SHAH', 'SHAHJAHANPUR'),
(1099, 'SHAP', 'SHAHPUR'),
(1100, 'SHAR', 'SHEOHAR'),
(1101, 'SHDO', 'SHAHDOL'),
(1102, 'SHEO', 'SHEOPUR'),
(1103, 'SHIM', 'SHIMLA'),
(1104, 'SHJ', 'SHARJAH'),
(1105, 'SHL', 'SHILLONG'),
(1106, 'SHM', 'SHIMOGA'),
(1107, 'SHO', 'SHOLAVANDAN'),
(1108, 'SHOL', 'SHOLINGANALLUR'),
(1109, 'SHOLA', 'SHOLAPUR'),
(1110, 'SHRA', 'SHEIKHPURA'),
(1111, 'SHRI', 'SHIVPURI'),
(1112, 'SHTI', 'SHRAWASTI'),
(1113, 'SHTL', 'SHERTALLAI'),
(1114, 'SHUR', 'SHAJAPUR'),
(1115, 'SIA', 'SINNAR'),
(1116, 'SIAR', 'SIBSAGAR'),
(1117, 'SID', 'SINDHANUR'),
(1118, 'SIDD', 'SIDDHARTHNAGAR'),
(1119, 'SIG', 'SHILIGURI'),
(1120, 'SIHI', 'SIROHI'),
(1121, 'SIK', 'SIKAR'),
(1122, 'SIKA', 'SIKANDRABAD'),
(1123, 'SIL', 'SILVASSA'),
(1124, 'SILI', 'SILIGURI'),
(1125, 'SIM', 'SIMLA'),
(1126, 'SIN', 'SINGAMPUNARI'),
(1127, 'SIO', 'SIOLIM-BARDEZ'),
(1128, 'SIR', 'SIRSA'),
(1129, 'SIRC', 'SIRCAIM'),
(1130, 'SIRG', 'SINDHUDURG'),
(1131, 'SITA', 'SITAPUR'),
(1132, 'SIUR', 'SIRMAUR'),
(1133, 'SIURI', 'SURI'),
(1134, 'SIV', 'SIVAGANGA'),
(1135, 'SKM', 'STOCKHOLM'),
(1136, 'SKS', 'SIVAKASI'),
(1137, 'SLG', 'SILLIGURI'),
(1138, 'SLL', 'SAOPALO'),
(1139, 'SLM', 'SALEM'),
(1140, 'SLO', 'OSLO'),
(1141, 'SLR', 'SILCHAR'),
(1142, 'SMH', 'SITAMARHI'),
(1143, 'SMP', 'SAVAI MADHOPUR'),
(1144, 'SMPR', 'SAMASTIPUR'),
(1145, 'SNG', 'SANGLI'),
(1146, 'SNGR', 'SANGAREDDY (A.P.)'),
(1147, 'SNK', 'SANKARAPURAM'),
(1148, 'SNR', 'SRINAGAR'),
(1149, 'SNY', 'SYDNEY'),
(1150, 'SOAT', 'SONIPAT'),
(1151, 'SOHI', 'SOUTH DELHI'),
(1152, 'SOL', 'SEOUL'),
(1153, 'SOLS', 'SOUTH GARO HILLS'),
(1154, 'SON', 'SOLAN'),
(1155, 'SONI', 'SONITPUR'),
(1156, 'SOOA', 'SOUTH GOA'),
(1157, 'SOR', 'SOLAPUR'),
(1158, 'SORA', 'SONBHADRA'),
(1159, 'SOTH', 'SOUTH'),
(1160, 'SOTR', 'SOUTH TRIPURA'),
(1161, 'SOUR', 'SONAPUR'),
(1162, 'SOWE', 'SOUTH WEST DELHI'),
(1163, 'SPL', 'SAOPALO'),
(1164, 'SPR', 'SAHARANPUR'),
(1165, 'SPT', 'SONEPAT'),
(1166, 'SRI', 'SRIKAKULAM'),
(1167, 'SRM', 'SARAM'),
(1168, 'SRT', 'SURAT'),
(1169, 'SRU', 'SIRUVACHUR'),
(1170, 'SSI', 'SIRSI'),
(1171, 'SSO', 'S.SOKKANATHAPURAM'),
(1172, 'STG', 'SANTIAGO'),
(1173, 'STH', 'SITHILINGAMADAM'),
(1174, 'STL', 'SEATTLE'),
(1175, 'STP', 'ST PETERBERG'),
(1176, 'STY', 'SATHYAMANGALAYAM'),
(1177, 'SUAR', 'SURENDRANAGAR'),
(1178, 'SUB', 'SULTAN\'S BATTERY'),
(1179, 'SUG', 'SURENDRA NAGAR'),
(1180, 'SUJA', 'SURGUJA'),
(1181, 'SUL', 'SULTANPUR'),
(1182, 'SUN', 'SUNDARAPANDIAPURAM'),
(1183, 'SUR', 'SURATGARH'),
(1184, 'SURH', 'SUNDARGARH'),
(1185, 'SURI', 'SURI'),
(1186, 'SUUL', 'SUPAUL'),
(1187, 'SWN', 'SIWAN'),
(1188, 'SWZ', 'SWITZERLAND'),
(1189, 'SZG', 'SALZBURG'),
(1190, 'TAAW', 'TAWANG'),
(1191, 'TAD', 'TADEPALLIGUDEM'),
(1192, 'TAK', 'TANUKU'),
(1193, 'TAN', 'TANJORE'),
(1194, 'TANG', 'TAMENGLONG'),
(1195, 'TAT', 'TARN  TARAN'),
(1196, 'TCR', 'TRICHUR'),
(1197, 'TDD', 'TRIMIDAD'),
(1198, 'TEAL', 'TEHRI GARHWAL'),
(1199, 'TEH', 'TEHRI'),
(1200, 'TEHSI', 'WRONGLY CREATED.DUMMY ENTRY.'),
(1201, 'TEI', 'THENI'),
(1202, 'TEN', 'TENKASI'),
(1203, 'TEZ', 'TEZU'),
(1204, 'TGA', 'TALAGUPPA'),
(1205, 'THA', 'THANA'),
(1206, 'THAL', 'THOUBAL'),
(1207, 'THAM', 'THIRUVANANTHAPURAM'),
(1208, 'THDI', 'THOOTHUKKUDI'),
(1209, 'THGS', 'THE DANGS'),
(1210, 'THIS', 'THE NILGIRIS'),
(1211, 'THL', 'THALTEJ'),
(1212, 'THNE', 'THANE'),
(1213, 'THO', 'THOTTIAPATTI'),
(1214, 'THUR', 'THIRUVALLUR'),
(1215, 'THUV', 'THIRUVARUR'),
(1216, 'TI', 'TENALI'),
(1217, 'TIAI', 'TIRUVANNAMALAI'),
(1218, 'TIAP', 'TIRAP'),
(1219, 'TILI', 'TIRUCHIRAPPALLI'),
(1220, 'TIM', 'THIRUVANNIMALAI'),
(1221, 'TIND', 'TINDIVANAM'),
(1222, 'TIR', 'TIRUPATHI'),
(1223, 'TIRH', 'TIKAMGARH'),
(1224, 'TIRU', 'TIRUPATHI'),
(1225, 'TIRUR', 'TIRUR'),
(1226, 'TIRV', 'TIRUVARUR'),
(1227, 'TIS', 'TISWADI GOA'),
(1228, 'TIV', 'TIVIM'),
(1229, 'TJR', 'THANJAVUR'),
(1230, 'TKA', 'THRIKKAKARA'),
(1231, 'TKR', 'THALAKKADATHUR'),
(1232, 'TKY', 'TOKYO'),
(1233, 'TLA', 'TIRUVALLA'),
(1234, 'TLS', 'THALASSERY'),
(1235, 'TLY', 'TELLICHERRY'),
(1236, 'TMP', 'THIRUMURUGANPOONDI'),
(1237, 'TND', 'TANDUR (R.R. DIST)'),
(1238, 'TNV', 'TIRUNELVELI'),
(1239, 'TONK', 'TONK'),
(1240, 'TP', 'TARAPUR'),
(1241, 'TPA', 'TRIPUNITHURA'),
(1242, 'TPB', 'TALIPARAMBA'),
(1243, 'TPE', 'TAIPEI'),
(1244, 'TPI', 'TIRUPATI'),
(1245, 'TPL', 'TRIPOLI'),
(1246, 'TPR', 'TEZPUR'),
(1247, 'TPU', 'TALAYOLAPARAMBU'),
(1248, 'TPZ', 'THODUPUZHA'),
(1249, 'TR1', 'TIRUPPATTUR (T.S.DIST)'),
(1250, 'TR2', 'TIRUPATTUR(P.T.T DIST)'),
(1251, 'TRI', 'TRICHY'),
(1252, 'TRL', 'TIRUVALAM'),
(1253, 'TRM', 'TIRUMANGALAM'),
(1254, 'TRR', 'TIRUPUR'),
(1255, 'TRS', 'THRISSUR'),
(1256, 'TRU', 'TIRUPUVANAM'),
(1257, 'TRV', 'TRIVANDRUM'),
(1258, 'TRY', 'TIRUCHIRAPALLY'),
(1259, 'TSK', 'TINSUKIA'),
(1260, 'TSR', 'TIRUSHUR'),
(1261, 'TTN', 'TUTICORIN'),
(1262, 'TUM', 'TUMKUR'),
(1263, 'TUNG', 'TUENSANG'),
(1264, 'TVA', 'TIRUVALLA'),
(1265, 'TVM', 'TIRUVANANTHAPURAM'),
(1266, 'TWN)', 'TWENTY FOUR PARGANAS(N)'),
(1267, 'TWS)', 'TWENTY FOUR PARGANAS(S)'),
(1268, 'UDA', 'UDAYAMARTHANDAPURAM'),
(1269, 'UDAL', 'UDALA'),
(1270, 'UDAR', 'UDHAM SINGH NAGAR'),
(1271, 'UDH', 'UDHAILYAH'),
(1272, 'UDM', 'UDUMALPET'),
(1273, 'UDP', 'UDUPI'),
(1274, 'UDR', 'UDAIPUR'),
(1275, 'UDU', 'UDHAMPUR'),
(1276, 'UHNR', 'ULHASNAGAR'),
(1277, 'UJN', 'UJJAIN'),
(1278, 'UKUL', 'UKHRUL'),
(1279, 'UMIA', 'UMARIA'),
(1280, 'UNA', 'UNA'),
(1281, 'UNJ', 'UNJHA'),
(1282, 'UNN', 'UNNAO'),
(1283, 'UPNG', 'UPPER SIANG'),
(1284, 'UPRI', 'UPPER SUBANSIRI'),
(1285, 'UTDA', 'UTTARA KANNADA'),
(1286, 'UTK', 'UTTARKASHI'),
(1287, 'UTUR', 'UTTAR DINAJPUR'),
(1288, 'VAD', 'VADAKKANULAM'),
(1289, 'VADK', 'VADAKARA'),
(1290, 'VAL', 'VALSAD'),
(1291, 'VALI', 'VAISHALI'),
(1292, 'VAN', 'VANCOUVER'),
(1293, 'VAP', 'VAPI'),
(1294, 'VAS', 'VASCO'),
(1295, 'VASHI', 'VASHI'),
(1296, 'VDR', 'VADODARA'),
(1297, 'VE', 'VASAI(E)'),
(1298, 'VEN', 'VENGUR'),
(1299, 'VER', 'VEERAPANDIAPATTINAM'),
(1300, 'VEREM', 'VEREM, GOA'),
(1301, 'VET', 'VETTAIKARANUPUDDUR'),
(1302, 'VIA', 'VIRACHILAI'),
(1303, 'VIAM', 'VILUPPURAM'),
(1304, 'VID', 'VIDISHA'),
(1305, 'VIJ', 'VIJAYANAGARAM'),
(1306, 'VIKH', 'VISAKHAPATNAM'),
(1307, 'VIL', 'VILLUPURAM'),
(1308, 'VIR', 'VIRUDHACHALAM'),
(1309, 'VIRE', 'VIRAR(E)'),
(1310, 'VIRW', 'VIRAR(W)'),
(1311, 'VIS', 'VISHAKAPATNAM'),
(1312, 'VIZ', 'VIZIANAGARAM'),
(1313, 'VJD', 'VIJAYAWADA'),
(1314, 'VKM', 'VAIKOM'),
(1315, 'VLN', 'VELLANUR'),
(1316, 'VLR', 'VELLORE'),
(1317, 'VLU', 'VALUTHOOR'),
(1318, 'VMD', 'VEMANDAMPALAYAM'),
(1319, 'VNA', 'VIENNA'),
(1320, 'VNL', 'VANIAMBADI'),
(1321, 'VNR', 'VIRUDHUNAGAR'),
(1322, 'VNS', 'VARANASI'),
(1323, 'VPY', 'VADANAPPALLY'),
(1324, 'VRE', 'VASAI ROAD(E)'),
(1325, 'VRK', 'VARKALA'),
(1326, 'VRL', 'VERAVAL'),
(1327, 'VRV', 'VRINDAVAN'),
(1328, 'VRW', 'VASAI ROAD(W)'),
(1329, 'VSK', 'VASCO DA GAMA'),
(1330, 'VVK', 'VLADIVOSTOCK'),
(1331, 'VVN', 'VALLABH VIDYA NAGAR'),
(1332, 'VVS', 'VANVASI'),
(1333, 'VW', 'VASAI (W)'),
(1334, 'VZM', 'VIZHINJAM'),
(1335, 'WAAD', 'WAYANAD'),
(1336, 'WAID', 'WAIDHAN  (M. P)'),
(1337, 'WAIM', 'WASHIM'),
(1338, 'WAR', 'WARDHA'),
(1339, 'WEAR', 'WEST NIMAR'),
(1340, 'WEHI', 'WEST DELHI'),
(1341, 'WELS', 'WEST GARO HILLS'),
(1342, 'WENG', 'WEST KAMENG'),
(1343, 'WERA', 'WEST TRIPURA'),
(1344, 'WERI', 'WEST GODAVARI'),
(1345, 'WEST', 'WEST'),
(1346, 'WGL', 'WARANGAL'),
(1347, 'WOHA', 'WOKHA'),
(1348, 'WSW', 'WARSAW'),
(1349, 'WTL', 'WELLINGTON'),
(1350, 'WTN', 'WELLINGTON'),
(1351, 'WYN', 'WYNAD'),
(1352, 'YAAL', 'YAVATMAL'),
(1353, 'YAAM', 'YANAM'),
(1354, 'YAAR', 'YAMUNANAGAR'),
(1355, 'YEL', 'YELAHANKA'),
(1356, 'YEM', 'YEMBAL'),
(1357, 'YGN', 'YANGON'),
(1358, 'YNR', 'YAMUNA NAGAR'),
(1359, 'ZCH', 'ZURICH'),
(1360, 'ZGB', 'ZAGREB'),
(1361, 'ZIR', 'ZIRAKPUR'),
(1362, 'ZUTO', 'ZUNHEBOTO');

-- --------------------------------------------------------

--
-- Table structure for table `corerole`
--

CREATE TABLE `corerole` (
  `roleId` int(11) NOT NULL,
  `roleName` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `isDel` int(11) NOT NULL DEFAULT 0,
  `system` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `corerole`
--

INSERT INTO `corerole` (`roleId`, `roleName`, `description`, `isDel`, `system`) VALUES
(1, 'Super Admin', '', 0, 1),
(2, 'HFC Admin', '', 0, 0),
(3, 'HFC Users', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `coreusers`
--

CREATE TABLE `coreusers` (
  `userId` int(11) NOT NULL,
  `fullName` varchar(255) NOT NULL,
  `emailId` varchar(255) NOT NULL,
  `passWord` varchar(255) NOT NULL,
  `isDel` int(11) NOT NULL DEFAULT 0,
  `roleId` int(11) NOT NULL,
  `creationDate` date NOT NULL,
  `empID` varchar(255) NOT NULL,
  `modifyOn` datetime NOT NULL,
  `deletionDate` datetime NOT NULL,
  `createdBy` int(11) NOT NULL,
  `deletedBy` int(11) NOT NULL,
  `isLogin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coreusers`
--

INSERT INTO `coreusers` (`userId`, `fullName`, `emailId`, `passWord`, `isDel`, `roleId`, `creationDate`, `empID`, `modifyOn`, `deletionDate`, `createdBy`, `deletedBy`, `isLogin`) VALUES
(1, 'HFC RPA Admin', 'hfc@icici.com', 'hfc@1234', 0, 1, '2016-08-03', '', '2019-06-07 14:46:11', '2017-10-24 19:10:22', 1, 0, 0),
(2, 'HFC Admin ', 'admin@hfc.com', 'wipro123', 0, 2, '2016-08-07', '', '2018-10-29 16:03:26', '2017-10-24 19:10:22', 1, 0, 0),
(3, 'HFC User', 'user@hfc.com', 'User@123', 0, 3, '0000-00-00', 'HE000827', '2019-01-07 18:36:24', '2017-10-24 19:10:22', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `hfccustdata`
--

CREATE TABLE `hfccustdata` (
  `id` int(255) NOT NULL,
  `TRNREFNO` varchar(255) NOT NULL,
  `BRCODE` varchar(255) DEFAULT NULL,
  `SBCODE` varchar(255) DEFAULT NULL,
  `BNKSRL` varchar(255) DEFAULT NULL,
  `APPLNO` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `ADD1` varchar(255) DEFAULT NULL,
  `ADD2` varchar(255) DEFAULT NULL,
  `ADD3` varchar(255) NOT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PIN` varchar(255) DEFAULT NULL,
  `TYPE` varchar(255) DEFAULT NULL,
  `TENURE` varchar(255) DEFAULT NULL,
  `CATE` varchar(255) DEFAULT NULL,
  `FOLIO` varchar(255) DEFAULT NULL,
  `EMPCODE` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `AMOUNT` varchar(255) DEFAULT NULL,
  ` PAYMODE` varchar(255) DEFAULT NULL,
  `INSTNO` varchar(255) DEFAULT NULL,
  `INSTDT` varchar(255) DEFAULT NULL,
  `PANGIR1` varchar(255) DEFAULT NULL,
  `DOB` varchar(255) DEFAULT NULL,
  `NGNAME` varchar(255) DEFAULT NULL,
  `BANKAC` varchar(255) DEFAULT NULL,
  `BANKNM` varchar(255) DEFAULT NULL,
  `BCITY` varchar(255) DEFAULT NULL,
  `MICR` varchar(255) DEFAULT NULL,
  `GNAME` varchar(255) DEFAULT NULL,
  `GPAN` varchar(255) DEFAULT NULL,
  `ACTYPE` varchar(255) DEFAULT NULL,
  `RTGSCOD` varchar(255) DEFAULT NULL,
  `NNAME` varchar(255) DEFAULT NULL,
  `NADD1` varchar(255) DEFAULT NULL,
  `NADD2` varchar(255) DEFAULT NULL,
  `NADD3` varchar(255) DEFAULT NULL,
  `NCITY` varchar(255) DEFAULT NULL,
  `NPIN` varchar(255) DEFAULT NULL,
  `ENCL` varchar(255) DEFAULT NULL,
  `TELNO` varchar(255) DEFAULT NULL,
  `JH1NAME` varchar(255) DEFAULT NULL,
  `JH2NAME` varchar(255) DEFAULT NULL,
  `JH1PAN` varchar(255) DEFAULT NULL,
  `JH2PAN` varchar(255) DEFAULT NULL,
  `JH1RELATION` varchar(255) DEFAULT NULL,
  `JH2RELATION` varchar(255) DEFAULT NULL,
  `HLDINGPATT` varchar(255) DEFAULT NULL,
  `SUBTYPE` varchar(255) DEFAULT NULL,
  `EMAILID` varchar(255) DEFAULT NULL,
  `MOBILENO` varchar(255) DEFAULT NULL,
  `IFSC` varchar(255) DEFAULT NULL,
  `text1` varchar(255) NOT NULL,
  `text2` varchar(255) NOT NULL,
  `text3` varchar(255) NOT NULL,
  `text4` varchar(255) NOT NULL,
  `text5` varchar(255) NOT NULL,
  `text6` varchar(255) NOT NULL,
  `text7` varchar(255) NOT NULL,
  `text10` varchar(255) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `cifid_1` varchar(100) DEFAULT NULL,
  `cifid_2` varchar(100) DEFAULT NULL,
  `cifid_3` varchar(100) DEFAULT NULL,
  `is_existing_cust_1` int(1) NOT NULL,
  `is_existing_cust_2` int(1) NOT NULL,
  `is_existing_cust_3` int(1) NOT NULL,
  `edit_cifid_1` int(1) NOT NULL,
  `edit_cifid_2` int(1) NOT NULL,
  `edit_cifid_3` int(1) NOT NULL,
  `AccountNo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hfccustdata`
--

INSERT INTO `hfccustdata` (`id`, `TRNREFNO`, `BRCODE`, `SBCODE`, `BNKSRL`, `APPLNO`, `NAME`, `ADD1`, `ADD2`, `ADD3`, `CITY`, `STATE`, `PIN`, `TYPE`, `TENURE`, `CATE`, `FOLIO`, `EMPCODE`, `STATUS`, `AMOUNT`, ` PAYMODE`, `INSTNO`, `INSTDT`, `PANGIR1`, `DOB`, `NGNAME`, `BANKAC`, `BANKNM`, `BCITY`, `MICR`, `GNAME`, `GPAN`, `ACTYPE`, `RTGSCOD`, `NNAME`, `NADD1`, `NADD2`, `NADD3`, `NCITY`, `NPIN`, `ENCL`, `TELNO`, `JH1NAME`, `JH2NAME`, `JH1PAN`, `JH2PAN`, `JH1RELATION`, `JH2RELATION`, `HLDINGPATT`, `SUBTYPE`, `EMAILID`, `MOBILENO`, `IFSC`, `text1`, `text2`, `text3`, `text4`, `text5`, `text6`, `text7`, `text10`, `filename`, `cifid_1`, `cifid_2`, `cifid_3`, `is_existing_cust_1`, `is_existing_cust_2`, `is_existing_cust_3`, `edit_cifid_1`, `edit_cifid_2`, `edit_cifid_3`, `AccountNo`) VALUES
(6, '7431276', 'ICICI Securities', '', '7431276', '7431276', 'MR MAYANK  GUPTA', 'HNO 102PARAS MEADOWS GREEN GLEN LAYOUT', 'BANGALORE BANGALORE', '3', 'BANGALORE', 'KARNATAKA', '560103', 'C', '12', 'P', '', '', 'R', '200000', 'DD', '7431276', '13/02/2020', 'ANLPM5730H', '16/06/1983', 'Prachi  Agarwal', '201074339', 'ICICI Bank', 'Bangalore M G Road', '560229002', '  ', '', 'SAVING', '', 'Prachi  Agarwal', 'H No 102 Paras Meadows', 'Green Glen Layout', 'Bellandur', 'BANGALORE', '560103', 'NO', '', '', '', '', '', '', '', 'Single', 'C', 'mayank.g83@gmail.com', '8971744899', 'ICIC0000002', 'ICICI Bank', '000201074339', 'ICIC0000002', 'W47057', '7431276', 'REC PAN OF MR MAYANK  GUPTA ANLPM5730H', 'REC DEMAT STAEMENT OF MR MAYANK  GUPTA', '14-Feb-20', '13-02-2020', '661005164', NULL, NULL, 1, 0, 0, 0, 0, 0, ''),
(7, '7431279', 'ICICI Securities', '', '7431279', '7431279', 'MR SUNIL  SONI', 'Q 303 PAN OASIS NEAR GLOBAL INDIAN', 'INTERNATIONAL SCHOOL SECTOR 70 NOIDA', '2', 'GAUTAM BUDDHA NAGAR', 'UTTAR PRADESH', '201301', 'C', '24', 'S', '', '', 'R', '500000', 'DD', '7431279', '13/02/2020', 'AABPS4528G', '13/10/1957', 'TUSHAR  SONI', '3101069335', 'ICICI Bank', 'New DelhiNoida', '110229005', '  ', '', 'SAVING', '', 'TUSHAR  SONI', 'Q303 PAN OASIS SECTOR 70 NOIDA', '', '', 'GAUTAM BUDDHA NAGAR', '201301', 'NO', '8903420', 'MS ROMILLA  SONI', '', 'BGZPS5290L', '', 'WIFE', '', 'Anyone or Surviovr', 'C', 'sonisunil@yahoo.com', '9810301926', 'ICIC0000031', 'ICICI Bank', '003101069335', 'ICIC0000031', 'W47058', '7431279', 'REC PAN OF MR SUNIL  SONI AABPS4528G', 'REC DEMAT STAEMENT OF MR SUNIL  SONI', '14-Feb-20', '13-02-2020', '661080625', '661080630', NULL, 0, 0, 0, 0, 0, 0, '150000619301'),
(5, '7431346', 'ICICI Securities', '', '7431346', '7431346', 'MR SANDEEP KUMAR SINGH', 'H NO 5 6 INDRAPURI KALONI I I M ROAD', 'TEH LUCKNOW', '2', 'LUCKNOW', 'UTTAR PRADESH', '226020', 'C', '12', 'P', '', '', 'R', '100000', 'DD', '7431346', '13/02/2020', 'BMJPS5852E', '04/02/1983', 'SURABHI  SINGH', '2101551310', 'ICICI Bank', 'Gurgaon', '110229003', '  ', '', 'SAVING', '', 'SURABHI  SINGH', 'PLOT NO. 5-6', 'INDRAPURI COLONY', 'IIM ROAD ', 'LUCKNOW', '226020', 'NO', '', '', '', '', '', '', '', 'Single', 'C', 'sandeepksingh.lko@gmail.com', '9453287687', 'ICIC0000021', 'ICICI Bank', '002101551310', 'ICIC0000021', 'W47061', '7431346', 'REC PAN OF MR SANDEEP KUMAR SINGH BMJPS5852E', 'REC DEMAT STAEMENT OF MR SANDEEP KUMAR SINGH', '14-Feb-20', '13-02-2020', '661080620', NULL, NULL, 0, 0, 0, 0, 0, 0, '150000619257');

-- --------------------------------------------------------

--
-- Table structure for table `hfc_state`
--

CREATE TABLE `hfc_state` (
  `id` int(11) NOT NULL,
  `state_name` varchar(255) NOT NULL,
  `short_state` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hfc_state`
--

INSERT INTO `hfc_state` (`id`, `state_name`, `short_state`) VALUES
(1, 'ANDAMAN & NICOBAR', 'AN'),
(2, 'ANDHRAPRADESH', 'AP'),
(3, 'ARUNACHAL PRADESH', 'AR'),
(4, 'ASSAM', 'AS'),
(5, 'BIHAR', 'BH'),
(6, 'CHANDIGARH', 'CH'),
(7, 'CHATTISGARH', 'CHHS'),
(8, 'DAMAN & DIU', 'DD'),
(9, 'DELHI', 'DL'),
(10, 'DADRA NAGAR HAVELI', 'DN'),
(11, 'GOA', 'GA'),
(12, 'GUJARAT', 'GJ'),
(13, 'HIMACHAL PRADESH', 'HP'),
(14, 'HARYANA', 'HR'),
(15, 'JHARKHAND', 'JHK'),
(16, 'JAMMU & KASHMIR', 'JK'),
(17, 'KARNATAKA', 'KA'),
(18, 'KERALA', 'KL'),
(19, 'LAKHSHDWEEP', 'LD'),
(20, 'MAHARASHTRA', 'MH'),
(21, 'MIG STATE CODE', 'MIG'),
(22, 'MEGHALAYA', 'ML'),
(23, 'MANIPUR', 'MN'),
(24, 'MADHYAPRADESH', 'MP'),
(25, 'MIZORAM', 'MZ'),
(26, 'NEW DELHI', 'ND'),
(27, 'NAGALAND', 'NL'),
(28, 'ORISSA', 'OR'),
(29, 'PUNJAB', 'PB'),
(30, 'GUJARAT GLASS LTD.', 'PGGL'),
(31, 'PONDICHERRY', 'PY'),
(32, 'RAJASTHAN', 'RJ'),
(33, 'SIKKIM', 'SK'),
(34, 'TELANGANA', 'TG'),
(35, 'TAMIL NADU', 'TN'),
(36, 'TRIPURA', 'TR'),
(37, 'TELANGANA', 'TS'),
(38, 'UTTARAKHAND', 'UK'),
(39, 'UTTAR PRADESH', 'UP'),
(40, 'UTTARANCHAL', 'UTH'),
(41, 'WEST BENGAL', 'WB');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bot_aps_tracking`
--
ALTER TABLE `bot_aps_tracking`
  ADD PRIMARY KEY (`tracking_id`);

--
-- Indexes for table `bot_aps_trackingold`
--
ALTER TABLE `bot_aps_trackingold`
  ADD PRIMARY KEY (`tracking_id`);

--
-- Indexes for table `bot_control_mst`
--
ALTER TABLE `bot_control_mst`
  ADD PRIMARY KEY (`control_id`);

--
-- Indexes for table `bot_error_logs`
--
ALTER TABLE `bot_error_logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `bot_ip_logins`
--
ALTER TABLE `bot_ip_logins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bot_process_dtl`
--
ALTER TABLE `bot_process_dtl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bot_process_mst`
--
ALTER TABLE `bot_process_mst`
  ADD PRIMARY KEY (`process_id`);

--
-- Indexes for table `bot_rejected_apps`
--
ALTER TABLE `bot_rejected_apps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bot_sequence_dtl`
--
ALTER TABLE `bot_sequence_dtl`
  ADD PRIMARY KEY (`seq_id`);

--
-- Indexes for table `city_data`
--
ALTER TABLE `city_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `corerole`
--
ALTER TABLE `corerole`
  ADD PRIMARY KEY (`roleId`);

--
-- Indexes for table `coreusers`
--
ALTER TABLE `coreusers`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `hfccustdata`
--
ALTER TABLE `hfccustdata`
  ADD PRIMARY KEY (`TRNREFNO`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `hfc_state`
--
ALTER TABLE `hfc_state`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bot_aps_tracking`
--
ALTER TABLE `bot_aps_tracking`
  MODIFY `tracking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `bot_aps_trackingold`
--
ALTER TABLE `bot_aps_trackingold`
  MODIFY `tracking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bot_error_logs`
--
ALTER TABLE `bot_error_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=213;

--
-- AUTO_INCREMENT for table `bot_ip_logins`
--
ALTER TABLE `bot_ip_logins`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bot_process_dtl`
--
ALTER TABLE `bot_process_dtl`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `bot_rejected_apps`
--
ALTER TABLE `bot_rejected_apps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `city_data`
--
ALTER TABLE `city_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1363;

--
-- AUTO_INCREMENT for table `corerole`
--
ALTER TABLE `corerole`
  MODIFY `roleId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `coreusers`
--
ALTER TABLE `coreusers`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1281;

--
-- AUTO_INCREMENT for table `hfccustdata`
--
ALTER TABLE `hfccustdata`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `hfc_state`
--
ALTER TABLE `hfc_state`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
